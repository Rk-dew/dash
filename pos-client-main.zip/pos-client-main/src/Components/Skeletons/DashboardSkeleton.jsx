import { CustomTypography } from '@mui/material'
import React from 'react'

function DashboardSkeleton() {
  return (
    <div>
      <CustomTypography>This is Skeleton</CustomTypography>
    </div>
  )
}

export default DashboardSkeleton
