
import {
  Box,
  Button,
  Fab,
  FormControl,
  Input,
  InputLabel,
  MenuItem,
  Modal,
  Paper,
  Select,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  TextField,
  Typography,
  radioClasses,
} from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import DeleteIcon from "@mui/icons-material/Delete";
import { add, remove, removeOneItem, resetState, selectSubtotal, updateQuantity } from "../../../Screens/store/foodSlice";
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import AccountCircleOutlinedIcon from '@mui/icons-material/AccountCircleOutlined';
import AssignmentIndIcon from '@mui/icons-material/AssignmentInd';
import { useDispatch, useSelector } from "react-redux";
import { useDrawer } from "../../Sidebar/DrawerContext";
import { useErrorSnackbar } from "../../../Screens/snackbar/ErrorSnackbarProvider";
import { useSuccessSnackbar } from "../../../Screens/snackbar/SuccessSnackbarProvider";
import axios from "axios";
import { updateOrderStatus } from "../../../Screens/store/foodSlice";
import PopOverModal from "../../Cards/Modal/PopOverModal";
import { useLocation } from "react-router-dom";
import QuickBill from "./QuickBill";
import { useReactToPrint } from "react-to-print";
import KotBill from "./KotBill";
import { useDarkMode } from "../../../Screens/DarkMode/DarkMode";
import { BorderTop } from "@mui/icons-material";

const CartTable = () => {
  const { isDarkMode, toggleDarkMode , CustomTypography} = useDarkMode();
  const { isCartOpen, closeCart } = useDrawer();
  const { showSuccessSnackbar } = useSuccessSnackbar();
  const { showErrorSnackbar } = useErrorSnackbar();
  const currentUser = useSelector((state) => state.auth.user.data);
  const { selectStyles } = useDrawer();
  const foodList = useSelector((state) => state.cart.bill.order[0].orderFoods);
  const orderData = useSelector((state) => state.cart);
  const tableNoValue = useSelector((state) => state.cart.bill.order[0].tableNo);
  const paymentmode = useSelector((state) => state.cart.bill.order[0].paymentMode);
  const isOrderFoodsNotEmpty = foodList.length > 0;
  const dispatch = useDispatch();
  const removeFromCart = (index) => {
    dispatch(remove(index));
  };

///fetched running tables and excluded it from mapped tables
  const [tableNumbers, setTableNumbers] = useState([]);
  const fetchPendingData = () => {
    axios
      .get(`https://apis.ubsbill.com/apptest/v2/bill/statusreport?orderStatus=Prepared&orderStatus=pending&orderStatus=preparing&orderStatus=Running&storeId=${currentUser.storeid}`,
      {
        headers: {
          Authorization: `Bearer ${currentUser.token}`
        }
      }
      )
      .then((response) => {
       const numbers = response.data.data.map(order => order.order[0].tableNo);
         setTableNumbers(numbers);
 })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  };
  
  useEffect(() => {
    fetchPendingData();
  }, []);
  const availableOptions = [1, 2, 3, 4, 5, 6, 7, 8 , 9 , 10 ,11 , 12 ,13].filter(number => {
    // If tableNumbers is provided and not empty, filter out the used numbers
    if (tableNumbers && tableNumbers.length > 0) {
        return !tableNumbers.includes(number.toString()) && number !== "";
    } else {
        // If tableNumbers is empty or not provided, show all tables
        return true;
    }
});
const [quantities, setQuantities] = useState(foodList.map(food => food.quantity));

const handleQuantityChange = (foodId, quantity) => {
 
  dispatch(updateQuantity({ foodId, quantity }));
};


  const handleOneItemRemove = (index) => {
    dispatch(removeOneItem(index));
  };

  const addToOrder = (food) => {
    dispatch(add(food));
    console.log("tableNumbers" , tableNumbers)
  };

  const [value, setValue] = useState(null);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const [open, setOpen] = useState(false);
  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
    dispatch(resetState());

  };
  const [openModal, setOpenModal] = useState(false);
  const handleOpenModal = () => {
    setOpenModal(true);
  };
  const handleCloseModal = () => {
    setOpenModal(false);
  };
  const [paymentModeValue, setPaymentModeValue] = useState(null);
  const [orderTypes, setOrderType] = useState("");
  const handleOrderTypeChange = (event, newValue) => {
    let orderType = "";
    switch (newValue) {
      case 0:
        orderType = "TAKE AWAY";
        dispatch(add({ orderType, tableNo: "" }));
        break;
        // orderType = "DINE IN";
        // dispatch(add({ orderType, tableNo: tableNo }));
        // break;
      case 1:
        orderType = "DELIVERY";

        dispatch(add({ orderType, tableNo: "" }));
        break;
      // case 2:
      //   orderType = "DELIVERY";

      //   dispatch(add({ orderType, tableNo: "" }));
      //   break;
      default:
        break;
    }
    setValue(newValue);
    setOrderType(orderType);
  };


  const orderTypeInRedux = () => {
    dispatch(add({ orderType: orderTypes })); 
  }

  useEffect(() => {
    orderTypeInRedux()
  }, []);
  const [paymentMode, setPaymentMode] = useState(""); 

  const handlePaymentModeChange = (event, newValue) => {
    let mode = "";
    switch (newValue) {
      case 0:
        mode = "Cash";
        break;
      case 1:
        mode = "Card";
        break;
      case 2:
        mode = "Upi";
        break;
      default:
        break;
    }
    dispatch(add({ paymentMode: mode })); 
    setPaymentMode(mode); // Update the paymentMode state
    setPaymentModeValue(newValue); // Update the payment mode value if needed
  };


  const total = useSelector((state) => state.cart.bill.total);

  // const [tableNo, setTableNo] = useState(null);

  // const handleTableNoChange = (event) => {
  //   const { value } = event.target;
  //   setTableNo(value);
  //   dispatch(add({ tableNo: value }));
  // };

  const [discountValue, setDiscountValue] = useState("");

  const handleDiscountChange = (event) => {

    const inputValue = event.target.value;
    setDiscountValue(inputValue);
    dispatch(add({ discount: inputValue === "" ? "" : inputValue }));
  };

  const [isPlacingOrder, setIsPlacingOrder] = useState(false);

  const handlePlaceOrder = async () => {
    setIsPlacingOrder(true);
    const newOrderStatus = "pending";
    const newPaymentMode = "";
    setPaymentModeValue();
    const updatedOrderData = {
      ...orderData,
      bill: {
        ...orderData.bill,
        storeId: currentUser.storeid,
        paymentMode: newPaymentMode,
        billStatus:"Place Order",
        updatedBy: currentUser.username,
        createdBy: currentUser.username,
        order: [
          {
            ...orderData.bill.order[0],
            orderStatus: newOrderStatus,
            storeId: currentUser.storeid,
            updatedBy: currentUser.username,
            createdName: currentUser.username,
          },
        ],
      },
    };

    try {
      if (value === null || value === undefined) {
        showErrorSnackbar('Please select an Order Type.');
        return;
      }

      // if (value === 0 && (tableNoValue === null || tableNoValue === undefined)) {
      //   showErrorSnackbar('Please select Table No for Dine in Order');
      //   return;
      // }

      dispatch(add({ orderStatus: 'pending', }));
      dispatch(add({ updatedOrderData }));

      const response = await axios.post("https://apis.ubsbill.com/apptest/v2/bill/", updatedOrderData , {
        headers: {
            'Authorization': `Bearer ${currentUser.token}`, 
            'Content-Type': 'application/json'
        }
    });
      if (response.data.status === true) {
        showSuccessSnackbar('Order placed successfully!');
        dispatch(resetState());
        // setTableNo(null);
        setDiscountValue("");
        fetchPendingData();
        orderTypeInRedux();
        closeCart();
      } 
      else {

        const errorResponse = response.data.message;
        const errorMessage = errorResponse ? errorResponse : 'Failed to place the order. Please try again.';
        showErrorSnackbar(errorMessage);
      }
    } catch (error) {
      console.error('Error while placing the order:', error);
      showErrorSnackbar(error.response.data.message);
    }
   finally {
     setIsPlacingOrder(false);
  }
  };

  const [billId, setBillId] = useState("");
  const [serialNo, setSerialNo] = useState("");

  const [isQuickOrder, setIsQuickOrder] = useState(false);

 
  const handleQuickBill = async (e) => {
    e.preventDefault();
    if (paymentModeValue === null || paymentModeValue === undefined) {
      showErrorSnackbar('Please select a payment mode before proceeding.');
      return;
    }
    setIsQuickOrder(true);
    console.log("paymentMode" , paymentMode)
    const newOrderStatus = "Completed";
    const updatedOrderData = {
      ...orderData,
      bill: {

        ...orderData.bill,
        storeId: currentUser.storeid,
        updatedBy: currentUser.username,
        billStatus:"Quick Bill",
        createdBy: currentUser.username,
        order: [
          {
            ...orderData.bill.order[0],
            storeId: currentUser.storeid,
            orderType: orderTypes,
            orderStatus: newOrderStatus,
            updatedBy: currentUser.username,
            createdName: currentUser.username,
          },
        ],
      },
    };
    try {

      if (value === null || value === undefined) {
        showErrorSnackbar('Please select an Order Type.');
        return;
      }
    
    

      dispatch(add({ orderStatus: 'Completed' }));
      dispatch(add(updatedOrderData));
      const response = await axios.post("https://apis.ubsbill.com/apptest/v2/bill/quick", updatedOrderData , {
        headers: {
            'Authorization': `Bearer ${currentUser.token}`, 
            'Content-Type': 'application/json'
        }
    });
      if (response.data.status === true) {
        console.log('this is my response' , response.data.data.serialNo)
        showSuccessSnackbar("Quick Bill Submited Successfully !");
        setOpenModal(true);
        setBillId(response.data.data.billId);
        setSerialNo(response.data.data.serialNo);
        orderTypeInRedux();
        setDiscountValue("");
        fetchPendingData();
        closeCart();
      
          handleSubmit();
          setIsVisible(true);
       
      } else {
        const errorResponse = response.data.message;
        const errorMessage = errorResponse ? errorResponse : 'Failed to place the order. Please try again.';
        showErrorSnackbar(errorMessage);
      }
    } catch (error) {
      console.error('Error while placing the order:', error);
      showErrorSnackbar(error.response.data.message);
    }
    finally {
      setIsQuickOrder(false);
   }
  };

  const sendWhatsAppMessage = async () => {
    try {
        const accountSid = 'AC6120559baab822160ed260e2ac9419b3';
        const authToken = '1d9145bca5e7a6fcf3cc1dce5525a519';

        const authHeader = 'Basic ' + btoa(`${accountSid}:${authToken}`);

      // Save the PDF to your server or cloud storage
        const pdfUrl = `http://192.168.0.156:8001/mobile-bill/${currentUser.storeid}/${serialNo}`;

        const messageBody = `🍽️ Order Placed Successfully 🍽️\n\n📋 Order Details:\n- Order ID: ${billId}\n- Total Amount: ${total}\n\n💸 Make Payment Here: upi://pay?pa=${upi}&am=${total}\n\n📄 Download Receipt: [PDF Receipt]( ${pdfUrl})`;

        const response = await axios.post(
            `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
            {
                Body: messageBody,
                From: 'whatsapp:+14155238886',
                To: 'whatsapp:+91' + formData.contact
            },
            {
                headers: {
                    Authorization: authHeader,
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
        );

        console.log(response.data);
        console.log('WhatsApp message sent successfully!');
      
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while sending the WhatsApp message.');
    }
};


  const handleSubmit = async (e) => {
  
    if (validateForm()) {
      try {
      
        // Once the WhatsApp message is sent successfully, proceed with form submission
        axios.post('https://apis.ubsbill.com/apptest/v2/sys/customer/', formData)
          .then((response) => {
            if (response.data.status === true) {
              console.log('response', response);
              console.log('formData', formData);
              showSuccessSnackbar("Form submitted successfully!");
              setFormData({
                contact: '',
                customerName: '',
                email: '',
                dateOfBirth: '',
              });
              sendWhatsAppMessage();
            } else {
              showErrorSnackbar(response.data.message);
            }
          })
          .catch((error) => {
            console.error('Error:', error);
            showErrorSnackbar('An error occurred while submitting the form. Please try again later.');
          });
      } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while sending the WhatsApp message. Please try again later.');
      }
    }
  };


  const [orderNo, setOrderNo] = useState("");
  const [iskotOrder, setIsKotOrder] = useState(false);
  //Kot 
  const handleKot = async (e) => {
    setIsKotOrder(true)
    const newOrderStatus = "Preparing";
    const updatedOrderData = {
      ...orderData,
      bill: {
        ...orderData.bill,
        storeId: currentUser.storeid,
        updatedBy: currentUser.username,
        billStatus:"KOT",
        paymentMode: paymentMode,
        createdBy: currentUser.username,
        order: [
          {
            ...orderData.bill.order[0],
            storeId: currentUser.storeid,
            orderType: orderTypes,
            orderStatus: newOrderStatus,
            updatedBy: currentUser.username,
            createdName: currentUser.username,
          },
        ],
      },
    };
    try {
      if (value === null || value === undefined) {
        showErrorSnackbar('Please select an Order Type.');
        return;
      }
      dispatch(add({ orderStatus: 'Preparing' }));
      dispatch(add(updatedOrderData));
      const response = await axios.post("https://apis.ubsbill.com/apptest/v2/bill/", updatedOrderData , {
        headers: {
            'Authorization': `Bearer ${currentUser.token}`, 
            'Content-Type': 'application/json'
        }
    });
      if (response.data.status === true) {
        showSuccessSnackbar("Kot Submited Successfully !");
        setOpen(true);

        setOrderNo(response.data.data.order[0].orderId)
        // setTableNo();
        orderTypeInRedux();
        setDiscountValue("");
        fetchPendingData();
        closeCart();
      } else {
        const errorResponse = response.data.message;
        const errorMessage = errorResponse ? errorResponse : 'Failed to place the order. Please try again.';
        showErrorSnackbar(errorMessage);
      }
      console.log(response)
    } catch (error) {
      console.error('Error while placing the order:', error);
      showErrorSnackbar(error.response.data.message);
    }
    finally {
      setIsKotOrder(false);
   }
  };

  const printableBillRef = React.useRef();
  const handlePrintBill = useReactToPrint({
    content: () => printableBillRef.current,

  });
  const [tax, setTax] = useState([]);
  // Function to calculate the total tax rate
  const { subtotal, discountAmount } = useSelector(selectSubtotal);
  const fetchTaxData = () => {
    axios.get(`https://apis.ubsbill.com/apptest/v2/tax/store/${currentUser.storeid}` , {
      headers: {
          'Authorization': `Bearer ${currentUser.token}`, 
          'Content-Type': 'application/json'
      }
  })
      .then((response) => {
        if (response.data && response.data.data) {
          setTax(response.data.data);
        }
      })
      .catch((error) => {
        showErrorSnackbar("Error Fetching Tax Data");
      });
  }

  useEffect(() => {
    fetchTaxData()
  }, []);

  const calculateTotalTaxRate = () => {
    let totalRate = 0;
    tax.forEach(taxItem => {
      totalRate += taxItem.rate;
    });
    return totalRate;
  }

  const calculateGrandTotal = () => {
    const totalTaxRate = calculateTotalTaxRate();
    const totalTaxAmount = (subtotal * totalTaxRate) / 100;

    return subtotal + totalTaxAmount;

  }

  console.log(currentUser)

  const handlePrintingQuickBill = async () => {
    try {
      const response = await axios.patch(
        `https://apis.ubsbill.com/apptest/v2/bill/printBill/${serialNo}?paymentMode=${paymentMode}&total=${calculateGrandTotal()}`,
        null, 
        {
          headers: {
            Authorization: `Bearer ${currentUser.token}`,
            'Content-Type': 'application/json',
          },
        }
      );
      
      handlePrintBill();
      handleCloseModal();
      dispatch(resetState());
    } catch (error) {
      console.error("Error occurred while Printing:", error);
      
    }
  };
  

  const handleNoQuickBill = async () => {
    try {
      const response = await axios.patch(
        `https://apis.ubsbill.com/apptest/v2/bill/printBill/${serialNo}?paymentMode=${paymentMode}&total=${calculateGrandTotal()}`,
        null,
        {
          headers: {
            Authorization: `Bearer ${currentUser.token}`,
            'Content-Type': 'application/json',
          },
        }
      );
      handleCloseModal();
      dispatch(resetState());
    } catch (error) {
      console.error("Error occurred while Printing:", error);
    
    }
  };
  

  // const handlePrintingQuickBill = () => {
  //   handlePrintBill();
  //   handleCloseModal();
  //   dispatch(resetState());
  // }

  const printableKotRef = React.useRef();
  const handlePrintKot = useReactToPrint({
    content: () => printableKotRef.current,

  });

  const handlePrinting = () => {
    handlePrintKot();
    handleClose();
    dispatch(resetState());
  }
  const location = useLocation();
  useEffect(() => {
    dispatch(resetState());
  }, [location.pathname, dispatch]);

 
 //to visible customer box
  const [isVisible, setIsVisible] = useState(true);
  const handleClick = () => {
    setIsVisible(!isVisible);
    
  };
  const handleInvisible = () => {
    setIsVisible(false);
  };
//to auto scroll
  const foodTableRef = useRef();
  useEffect(() => {
    if (foodTableRef.current) {
      const lastRow = foodTableRef.current.lastElementChild;
      if (lastRow) {
        lastRow.scrollIntoView({ behavior: 'smooth', block: 'end', inline: 'nearest' });
      }
    }
  }, [foodList]);

  const [formData, setFormData] = useState({
        contact: '',
        customerName: '',
        email: '',
        dateOfBirth: '',
        storeId: `${currentUser.storeid}`,
  });
  const [errors, setErrors] = useState({});
  
  // Define your fields
  const fields = [
    { id: 'contact', label: 'Mobile No :' , type: 'number' },
    { id: 'customerName', label: 'Name :' , type: 'text' },
    { id: 'email', label: 'Email :' , type: 'email'},
    { id: 'dateOfBirth', label: 'Date of Birth :' , type: 'date'},
  ];

  // Step 2: Handle Input Changes
  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [id]: value,
    }));
  };

  // Step 3: Error Handling
  const validateForm = () => {
    let valid = true;
    const newErrors = {};

    // Example validation: Check if email is valid
    if (!formData.email.includes('@')) {
      newErrors.email = 'Invalid email address';
      valid = false;
    }

    setErrors(newErrors);
    return valid;
  };

  // Step 4: Handle Submit
  // const handleSubmit = (e) => {
  //   e.preventDefault();
  //   if (validateForm()) {
   
  //    axios.post('https://apis.ubsbill.com/apptest/v2/sys/customer/' , formData)
  //    .then((response) => {
  //     if(response.data.status === true) {
  //       console.log('response' , response);
  //       console.log('formData' , formData);
  //       showSuccessSnackbar("Form Submit successfully !");
  //       setFormData({
  //         contact: '',
  //         customerName: '',
  //         email: '',
  //         dateOfBirth: '',
  //       });
  //     } 
  //     else{
  //       showErrorSnackbar(response.data.message);
  //     }
  //    })
     
  //   }
  // };
  const [upi, setText] = useState([]);
  const fetchUpiData = async () => {
    try {
      const url = `https://apis.ubsbill.com/apptest/v2/sys/storePayment/store/${currentUser.storeid}`
      const response = await fetch(url);
      const json = await response.json();
      setText(json.data[0].upiId);
      console.log("upi" , json.data[0].upiId)
    } catch (error) {
      console.error("Error fetching inventory data:", error);
    }
  };
  useEffect(() => {
    fetchUpiData();
  }, []);



  return (
    <Box sx={{  paddingBottom : { xs: 0, sm: 0, md: "8vh", lg: 0 },}}>
      <Box
        sx={{
          boxShadow: "0px 4px 4px 0px #00000040",
          backgroundColor: isDarkMode ? '#5e5e5e' : '#cef2f2',
          borderRadius: "10px",
        }}
      >
        <Box
          className="carttable"
          p={2}
          sx={{
            display: "flex",
            alignItems: "left",
            flexDirection: "column",
            flex: 0,
            gap: { sm: "1", md: 0.7, xs: 0.8, xl: 1, lg: 0.8 },
          }}
        >
          <Box>
          <CustomTypography
            className="food-card-text"
            variant="h6"
            sx={{
              fontSize: {
                sm: "26px",
                md: "18px",
                xs: "16px",
                xl: "20px",
                lg: "23px",
              },
              fontWeight: "500",
              lineHeight: {
                sm: "15px",
                md: "14px",
                xs: "20px",
                xl: "20px",
                lg: "20px",
              },
            }}
          >
            Current Order
          </CustomTypography>
          </Box>
          <Tabs
            className="justify-all-center"
            value={value}
            onChange={handleOrderTypeChange}
            textColor="white"
            indicatorColor="white"
            aria-label="tabs"
            sx={{
              backgroundColor: isDarkMode ? '#8f8d8d' : '#fff',
              display:"flex",
              justifyContent:"space-evenly",
              
              borderRadius: "5px",
              padding: "10px 4px",
              height: {
                sm: "40px",
                md: "40px",
                xs: "30px",
                xl: "45px",
                lg: "30px",
              },
              minHeight: {
                sm: "20px",
                md: "14px",
                xs: "12px",
                xl: "45px",
                lg: "40px",
              },
              width: {
                sm: "100%",
                md: "100%",
                xs: "100%",
                xl: "100%",
                lg: "100%",
              },
            }}
          >
            {/* <Tab
              label="DINE IN"
              className="food-card-text cart-button justify-all-center"
              sx={{
              
                textAlign: "center",
                bgcolor: value === 0 ? (isDarkMode ? "#fff" : "#28A497") : (isDarkMode ? "#8f8d8d" : "inherit"),
                color: value === 0 ? (isDarkMode ? "black" : "white") : (isDarkMode ? "white" : "black"),
                padding: {
                  xl: "8px 5px",
                  lg: "0px 16px",
                  xs: "0px 5px",
                  sm: "3px 5px",
                },
                fontSize: {
                  sm: "15px",
                  md: "14px",
                  xs: "11px",
                  xl: "16px",
                  lg: "12px",
                },
                minHeight: {
                  sm: "20px",
                  md: "14px",
                  xs: "12px",
                  xl: "38px",
                  lg: "40px",
                },
              }}
            /> */}
            <Tab
              className="food-card-text cart-button justify-all-center"
              label="TAKE AWAY"
              sx={{
                bgcolor: value === 0 ? (isDarkMode ? "#fff" : "#28A497") : (isDarkMode ? "#8f8d8d" : "inherit"),
                color: value === 0 ? (isDarkMode ? "black" : "white") : (isDarkMode ? "white" : "black"),
               padding: {
                  xl: "10px 7px",
                  lg: "8px 8px",
                  xs: "0px 5px",
                  md: "6px 8px",
                  sm: "3px 5px",
                },
                width: "45%",
                fontSize: {
                  sm: "15px",
                  md: "12px",
                  xs: "11px",
                  xl: "14px",
                  lg: "12px",
                },
                minHeight: {
                  sm: "20px",
                  md: "14px",
                  xs: "12px",
                  xl: "40px",
                  lg: "40px",
                },
              }}
            />
            <Tab
              label="DELIVERY"
              className="food-card-text cart-button justify-all-center"
              sx={{
                bgcolor: value === 1 ? (isDarkMode ? "#fff" : "#28A497") : (isDarkMode ? "#8f8d8d" : "inherit"),
                color: value === 1 ? (isDarkMode ? "black" : "white") : (isDarkMode ? "white" : "black"),
                padding: {
                  xl: "0px 25px",
                  lg: "0px 16px",
                  xs: "0px 0px",
                  sm: "3px 5px",
                },
                width: "45%",
                fontSize: {
                  sm: "15px",
                  md: "12px",
                  xs: "11px",
                  xl: "14px",
                  lg: "12px",
                },
              }}
            />
          </Tabs>
          {/* {value === 0 && (
            <Box className="align-items-center">
              <CustomTypography
                variant="h6"
                className="food-card-text"
                sx={{
                  fontSize: {
                    sm: "17px",
                    md: "15px",
                    xs: "12px",
                    xl: "16px",
                    lg: "13px",
                  },
                  fontWeight: "500",
                  lineHeight: "30px",
                  minWidth: {
                    sm: "97px",
                    md: "105px",
                    xs: "97px",
                    xl: "97px",
                    lg: "102px",
                  },
                }}
              >
                Table No:
              </CustomTypography>
              <FormControl halfWidth sx={{ flex: 1 }}>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  onChange={handleTableNoChange}
                  value={tableNo}
                  className='food-card-text'
                  sx={{
                    ...selectStyles,
                    color: isDarkMode ? "#fff" : "#000000",
                    background: isDarkMode ? "#8f8d8d" :"#fff",
                    maxHeight: "35px",
                    height: "35px",
                    minHeight: "35px",
                    fontWeight: "500",
                    width: "100px",
                  }}
                >

                     {availableOptions.map((number) => (
            <MenuItem key={number} value={number}>
              {number}
            </MenuItem>
          ))}

                </Select>
              </FormControl>
            </Box>
          )} */}
          <Box
            className="payment-mode-main"
            sx={{ radius: "5px", display: "flex", alignItems: "center" }}
          >
            <CustomTypography
              className="food-card-text"
              sx={{
                fontSize: {
                  sm: "17px",
                  md: "13px",
                  xs: "12px",
                  xl: "16px",
                  lg: "13px",
                },
                fontWeight: "500",
                lineHeight: "25px",
                minWidth: {
                  sm: "97px",
                  md: "105px",
                  xs: "97px",
                  xl: "97px",
                  lg: "102px",
                },
              }}
            >
              Payment Mode
            </CustomTypography>

            <Tabs
              className=""
              value={paymentModeValue}
              onChange={handlePaymentModeChange}
              textColor="white"
              indicatorColor="white"
              aria-label="tabs"
              sx={{
                padding: "5px",
                radius: "5px",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <Tab
                label="CASH"
                className="food-card-text mode-button border-radius-10 cart-button"
                sx={{
               
                  bgcolor: paymentModeValue === 0 ? (isDarkMode ? "#fff" : "#28A497") : (isDarkMode ? "#8f8d8d" : "#D9D9D9"),
                  color: paymentModeValue === 0 ? (isDarkMode ? "black" : "white") : (isDarkMode ? "white" : "black"),
                  padding: {
                    sm: "10px 25px",
                    md: "5px 8px",
                    xs: "0px 15px",
                    xl: "5px 8px",
                    lg: "7px 5px",
                  },
                  fontSize: {
                    sm: "15px",
                    md: "12px",
                    xs: "12px",
                    xl: "14px",
                    lg: "12px",
                  },
                  minWidth: {
                    sm: "15px",
                    md: "14px",
                    xs: "12px",
                    xl: "65px",
                    lg: "60px",
                  },
                  marginLeft: {
                    sm: "15px",
                    md: "5px",
                    xs: "5px",
                    xl: "7px",
                    lg: "10px",
                  },
                }}
              />
              <Tab
                className="food-card-text mode-button border-radius-10"
                label="CARD"
                sx={{
               
                  bgcolor: paymentModeValue === 1 ? (isDarkMode ? "#fff" : "#28A497") : (isDarkMode ? "#8f8d8d" : "#D9D9D9"),
                  color: paymentModeValue === 1 ? (isDarkMode ? "black" : "white") : (isDarkMode ? "white" : "black"),
                  padding: {
                    sm: "10px 25px",
                    md: "5px 8px",
                    xs: "0px 15px",
                    xl: "5px 8px",
                    lg: "7px 5px",
                  },
                  fontSize: {
                    sm: "15px",
                    md: "12px",
                    xs: "12px",
                    xl: "14px",
                    lg: "12px",
                  },
                  minWidth: {
                    sm: "15px",
                    md: "14px",
                    xs: "12px",
                    xl: "65px",
                    lg: "60px",
                  },
                  marginLeft: {
                    sm: "15px",
                    md: "5px",
                    xs: "5px",
                    xl: "7px",
                    lg: "10px",
                  },
                }}
              />
              <Tab
                label="UPI"
                className="food-card-text mode-button border-radius-10"
                sx={{
                  
                  bgcolor: paymentModeValue === 2 ? (isDarkMode ? "#fff" : "#28A497") : (isDarkMode ? "#8f8d8d" : "#D9D9D9"),
                  color: paymentModeValue === 2 ? (isDarkMode ? "black" : "white") : (isDarkMode ? "white" : "black"),
                  padding: {
                    sm: "10px 25px",
                    md: "5px 8px",
                    xs: "0px 15px",
                    xl: "5px 8px",
                    lg: "7px 5px",
                  },
                  fontSize: {
                    sm: "15px",
                    md: "12px",
                    xs: "12px",
                    xl: "14px",
                    lg: "12px",
                  },
                  minWidth: {
                    sm: "15px",
                    md: "14px",
                    xs: "12px",
                    xl: "65px",
                    lg: "60px",
                  },
                  marginLeft: {
                    sm: "15px",
                    md: "5px",
                    xs: "5px",
                    xl: "7px",
                    lg: "10px",
                  },
                }}
              />
            </Tabs>
          </Box>
          <Box
            className="percent-box"
            sx={{ display: "flex", gap: 4, alignItems: "center" }}
          >
            <CustomTypography
              className="food-card-text"
              sx={{
                fontSize: {
                  sm: "17px",
                  md: "13px",
                  xs: "12px",
                  xl: "16px",
                  lg: "13px",
                },
                fontWeight: "500",
                lineHeight: "30px",
              }}
            >
              Discount Rate
            </CustomTypography>
            <input
              value={discountValue}
              maxLength={2}
              onChange={handleDiscountChange}
              className="percentage-input food-card-text"
              variant="outlined"
              style={{
                paddingLeft: "10px",
                maxWidth: "25%",
                color: isDarkMode ? "#fff" : "#000000",
                background: isDarkMode ? "#8f8d8d" :"#fff",
                fontWeight: "500",
                minHeight: "30px",
                borderRadius: "5px",
                border: "1px solid #8f8d8d",
              }}
            />
          </Box>
        </Box>

        <TableContainer
          className="cart-table"
          component={Paper}
          sx={{
            minHeight: {
              sm: "20vh",
              md: "25vh",
              xs: "25vh",
              xl: "38vh",
              lg: "35vh",
            },
            maxHeight: {
              sm: "20vh",
              md: "25vh",
              xs: "25vh",
              xl: "38vh",
              lg: "40vh",
            },
            backgroundColor: isDarkMode ? '#5e5e5e' : '#fff',
          }}
        >
          <Table sx={{ maxWidth: "100%" }} aria-label="simple table">
            <TableHead
              sx={{
                backgroundColor: isDarkMode ? '#8f8d8d' : '#28A497',
                position: "sticky",
                top: 0,
                zIndex: 1,
                padding: {
                  sm: 300,
                  md: 350,
                  xs: 300,
                  xl: "18px 25px",
                  lg: "8px 15px",
                },
                height: {
                  sm: "15px",
                  md: "14px",
                  xs: "12px",
                  xl: "50px",
                  lg: "20px",
                },
              }}
            >
              <TableRow>
                <TableCell
                  className="table-cell food-card-text"
                  size="small"
                  align="left"
                  sx={{
                    fontSize: {
                      xl: "16px",
                      lg: "14px",
                      md: "12px",
                      xs: "12px",
                      sm: "18px",
                    },
                    width: {
                      xl: "10vw",
                      lg: "10vw",
                      md: "8vw",
                      xs: "30vw",
                      sm: "40%",
                    },

                    fontWeight: "500",
                    color: "#FFFFFF",
                  }}
                >
                  Item
                </TableCell>
                <TableCell
                  className="table-cell food-card-text"
                  size="small"
                  align="left"
                  sx={{
                    fontSize: {
                      xl: "16px",
                      lg: "14px",
                      md: "12px",
                      xs: "12px",
                      sm: "18px",
                    },
                    fontWeight: "500",
                    color: "#FFFFFF",
                    width: {
                      xl: "2.5vw",
                      lg: "2.5vw",
                      md: "2.5vw",
                      xs: "10vw",
                      sm: "20%",
                    },
                    maxWidth: {
                      xl: "3vw",
                      lg: "3vw",
                      md: "2.5vw",
                      xs: "150vw",
                      sm: "20%",
                    },
                  }}
                >
                  Price
                </TableCell>
                <TableCell
                  className="table-cell food-card-text"
                  size="small"
                  align="left"
                  sx={{
                    fontSize: {
                      xl: "16px",
                      lg: "14px",
                      md: "12px",
                      xs: "12px",
                      sm: "18px",
                    },
                    fontWeight: "500",
                    color: "#FFFFFF",
                    
                    maxWidth: {
                      xl: "5vw",
                      lg: "5vw",
                      md: "5vw",
                      xs: "20vw",
                      sm: "40%",
                    },
                    width: {
                      xl: "5vw",
                      lg: "5vw",
                      md: "5vw",
                      xs: "20vw",
                      sm: "40%",
                    },
                  }}
                >
                  Quantity
                </TableCell>
                <TableCell
                  className="table-cell food-card-text"
                  size="small"
                  align="left"
                  sx={{
                    fontSize: {
                      xl: "16px",
                      lg: "14px",
                      md: "12px",
                      xs: "12px",
                      sm: "18px",
                    },
                    fontWeight: "500",
                    color: "#FFFFFF",
                    width: {
                      xl: "6vw",
                      lg: "4.5vw",
                      md: "6vw",
                      xs: "20%",
                      sm: "10%",
                    },
                    maxWidth: {
                      xl: "4vw",
                      lg: "4.5vw",
                      md: "6vw",
                      xs: "20%",
                      sm: "10%",
                    },
                  }}
                >
                  Action
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody
              sx={{
               
                backgroundColor: isDarkMode ? '#525151' : '#cef2f2',
                boxShadow: "0px 4px 4px 0px #00000040",
                pb: "0px",
                overflow: "hidden",
                zIndex:1,
                maxHeight: {
                  xl: "35vh",
                  lg: "35vh",
                  md: "25vh",
                  xs: "35vh",
                  sm: "65vh",
                },
              }}
              className="table-padding cart-table" ref={foodTableRef}
            >
              {foodList.map((food, index) => (
                <TableRow
                  className="cart-table"
                  key={index}
                  sx={{
                    border: "none",
                    "&:last-child td, &:last-child th": { border: 0 },
                  }}
                >
                  <TableCell
                    className="cart-td food-card-text"
                    size="small"
                    align="left"
                    sx={{
                      fontWeight: "400",
                      color: isDarkMode ? '#fff' : '#000',
                      minWidth: {
                        xl: "10vw",
                        lg: "10vw",
                        md: "8vw",
                        xs: "30vw",
                        sm: "40%",
                      },
                     
                      fontSize: {
                        xl: "15px",
                        lg: "13px",
                        md: "12px",
                        xs: "11px",
                        sm: "15px",
                      },
                      lineHeight: {
                        xl: "20px",
                        lg: "17px",
                        md: "18px",
                        xs: "12px",
                        sm: "20px",
                      },
                    }}
                  >
                    {food.foodName}
                    {/* <Button
                      className="food-card-text   final-button"
                      sx={{
                        fontSize: {
                          sm: "8px",
                          md: "8px",
                          xs: "8px",
                          xl: "8px",
                          lg: "8px",
                        },ml:"5px",
                        background: isDarkMode ? '#8F8D8D' : '#28A497',
                        color: isDarkMode ? '#fff' : '#fff',
                        fontWeight: "600",
                        maxHeight:"30px",
                        width:"50px",
                       borderRadius:"10px",
                        minWidth:"50px",
                      }}
                    >
                      +Addon</Button> */}
                  </TableCell>
                  
                  <TableCell
                    className="cart-td food-card-text"
                    size="small"
                    align="left"
                    sx={{
                      fontWeight: "400",
                      color: isDarkMode ? '#fff' : '#000',
                      fontSize: {
                        xl: "16px",
                        lg: "14px",
                        md: "12px",
                        xs: "11px",
                        sm: "15px",
                      },
                      lineHeight: "30px",
                      width: {
                        xl: "3vw",
                        lg: "3vw",
                        md: "3vw",
                        xs: "10vw",
                        sm: "20%",
                      },
                      maxWidth: {
                        xl: "3vw",
                        lg: "3vw",
                        md: "3vw",
                        xs: "10vw",
                        sm: "20%",
                      },
                    }}
                  >
                    {food.price}
                  </TableCell>
                    <TableCell
                    className="cart-td food-card-text"
                    size="small"
                    align="right"
                    sx={{
                      fontWeight: "400",
                      color: isDarkMode ? '#fff' : '#000',
                      fontSize: {
                        xl: "16px",
                        lg: "16px",
                        md: "14px",
                        xs: "12px",
                        sm: "15px",
                      },
                      lineHeight: "30px",
                      width: {
                        xl: "1vw",
                        lg: "1vw",
                        md: "1vw",
                        xs: "18vw",
                        sm: "20%",
                      },
                      maxWidth: {
                        xl: "1vw",
                        lg: "1vw",
                        md: "1vw",
                        xs: "18vw",
                        sm: "20%",
                      },
                    }}
                  >
                    <Box
                      sx={{
                       
                        background: isDarkMode ? '#8f8d8d' : '#FFFFFF',
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        padding: "3px",
                        width: {
                          xl: "5vw",
                          lg: "6vw",
                          md: "5vw",
                          xs: "20vw",
                          sm: "40%",
                        },
                        minWidth: {
                          xl: "5vw",
                          lg: "6vw",
                          md: "5vw",
                          xs: "20vw",
                          sm: "40%",
                        },
                        borderRadius: "10px",
                      }}
                      className="cart-td"
                    >
                      <Typography
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                        }}
                      >
                        <Typography
                           onClick={() => handleQuantityChange(food.foodId, parseInt(quantities[index] !== undefined ? quantities[index] : food.quantity) + 1)}
                          variant="span"
                          className="food-card-text food-card-icon"
                          sx={{
                            cursor: "pointer",
                            background: isDarkMode ? '#5e5e5e' : '#D9D9D9',
                            padding: "0px 6px",
                            marginRight: {
                              xl: "6px",
                              lg: "5px",
                              md: "5px",
                              xs: "2px",
                              sm: "6px",
                            },
                            fontSize: {
                              xl: "16px",
                              lg: "14px",
                              md: "14px",
                              xs: "12px",
                              sm: "16px",
                            },
                            borderRadius: {
                              xl: "9px",
                              lg: "8px",
                              md: "5px",
                              xs: "3px",
                              sm: "2px",
                            },
                          }}
                        >
                          +
                        </Typography>
                        <input
                           value={quantities[index] !== undefined ? quantities[index] : food.quantity}
                           onChange={(e) => handleQuantityChange(food.foodId, e.target.value)}
                          style={{
                            background: isDarkMode ? '#8f8d8d' : '#fff',
                            color: isDarkMode ? '#fff' : '#000',
                            width: "20px",
                            textAlign: "center",
                            border: "none",
                          }}
                          
                          className="food-card-text"
                        />
                        <Typography
                          onClick={() => handleOneItemRemove(index)}
                          variant="span"
                          className="food-card-text food-card-icon"
                          sx={{
                            cursor: "pointer",
                            background: isDarkMode ? '#5e5e5e' : '#D9D9D9',
                            padding: "0px 6px",
                            marginLeft: {
                              xl: "6px",
                              lg: "5px",
                              md: "5px",
                              xs: "2px",
                              sm: "6px",
                            },
                            fontSize: {
                              xl: "16px",
                              lg: "14px",
                              md: "14px",
                              xs: "12px",
                              sm: "16px",
                            },
                            borderRadius: {
                              xl: "9px",
                              lg: "8px",
                              md: "5px",
                              xs: "3px",
                              sm: "2px",
                            },
                          }}
                        >
                          -
                        </Typography>
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell
                    className="table-cell cart-td"
                    size="small"
                    align="left"
                    sx={{
                      padding: "8px",
                      width: {
                        xl: "6vw",
                        lg: "4.5vw",
                        md: "6vw",
                        xs: "20%",
                        sm: "10%",
                      },
                      maxWidth: {
                        xl: "4vw",
                        lg: "4.5vw",
                        md: "6vw",
                        xs: "20%",
                        sm: "10%",
                      },
                    }}
                  >
                    <Button
                      onClick={() => removeFromCart(index)}
                      size="small"
                      sx={{ color: "#000" }}
                    >
                      <DeleteIcon sx={{color: isDarkMode ? "#fff" : "#000"}}/>
                    </Button>
                  </TableCell>
                </TableRow>
                
              ))}
               
               
            </TableBody>
           
            </Table>
            
        </TableContainer>
        {/* <Box  sx={{}}>
        <Box
  sx={{
    height: isVisible ? 0 : "25vh",
    marginTop: isVisible ? 0 : "-25vh",
    background: "#fff",
    // paddingTop: isVisible ? 0 : 2,
    position: "relative",
    transition: "height 0.5s ease, margin 0.5s ease",
    overflow: "hidden",
    borderTop: '1px solid #28A497',
    display: 'flex',
    flexDirection: 'column',
    gap: '8px',
    paddingLeft:  4,
  }}
>
      {fields.map((field , index) => (
        <Box key={field.id } sx={{ display: "flex", alignItems: "center",  marginTop: index === 0 ? 2 : 0 }}>
          <CustomTypography className="food-card-text" sx={{ width: '100px' }}>{field.label}</CustomTypography>
          <TextField id={field.id} variant="outlined" size="small" value={formData[field.id]} type={field.type} onChange={handleInputChange} />
        </Box>
      ))}
     
      {errors.email && <span>{errors.email}</span>}
      
      
</Box>

   <Box  onClick={handleClick} sx={{cursor:"pointer", display: "flex", justifyContent: "left", background:"#cef2f2" ,borderBottomLeftRadius:"6px", borderBottomRightRadius:"6px" , paddingLeft:3, paddingTop:1, paddingBottom: 1 }}>
        <AccountCircleOutlinedIcon sx={{ fontSize: "30px" , color:"#000"}}  />
      </Box>
        </Box> */}
        <Box
          className="justify-all-center"
          sx={{
            background: isDarkMode ? '#8e8e8e' : '#fff',
            padding: {
              sm: "0px 15px",
              md: "0px 15px",
              xs: "0px 15px",
              xl: "10px 25px",
              lg: "10px 12px",
            },
            height: {
              sm: "35px",
              md: "40px",
              xs: "35px",
              xl: "35px",
              mt: "30px",
              lg: "25px",
            },
            marginTop: {
              sm: "2px",
              md: "0px",
              xs: "12px",
              xl: "5px",
              lg: "5px",
            },
          }}
        >
          <CustomTypography
            className="food-card-text"
            size="small"
            align="left"
            sx={{
              fontWeight: "600",
              fontSize: {
                xl: "20px",
                lg: "16px",
                md: "16px",
                xs: "12px",
                sm: "16px",
              },
              lineHeight: "30px",
            }}
          >
            Total
          </CustomTypography>
          <CustomTypography
            className="food-card-text"
            size="small"
            align="left"
            sx={{
              fontWeight: "600",
              fontSize: {
                xl: "20px",
                lg: "16px",
                md: "16px",
                xs: "12px",
                sm: "16px",
              },
              lineHeight: "30px",
              marginLeft: "auto",
            }}
          >
            ₹ {total}
          </CustomTypography>
        </Box>
        <Box
          sx={{
            minHeight: {
              xl: "15px",
              lg: "15px",
              sm: "0px",
              xs: "0px",
              md: "20px",
            },
          }}
        ></Box>
      </Box>

      <Box
        className="justify-all-center"
        sx={{
          boxShadow: "0px 4px 4px 0px #00000040",
          background: isDarkMode ? '#5e5e5e' : '#cef2f2',
          mt: { sm: 0, md: 2.4, xs: 0, xl: 2.4, lg: 2.4 },
          borderRadius: {
            sm: "0px",
            md: "10px",
            xs: "0px",
            xl: "10px",
            lg: "10px",
          },
          minHeight: {
            sm: "50px",
            md: "45px",
            xs: "50px",
            xl: "55px",
            mt: "30px",
            lg: "50px",
          },
          justifyContent: "space-evenly",
        }}
      >
        {/* <Button
          className="food-card-text border-radius-10 cart-button final-button"
          sx={{
            padding: {
              sm: "5px 15px",
              md: "5px 10px",
              xs: "4px 10px",
              xl: "6px 10px",
              lg: "5px 5px",
            },
            fontSize: {
              sm: "15px",
              md: "14px",
              xs: "12px",
              xl: "16px",
              lg: "10px",
            },
            background: isDarkMode ? '#8f8d8d' : '#D9D9D9',
            color: "#000000",
            fontWeight: "600",
          }}
        >
          <img src="../images/calculator.png" alt={`calculator Icon`} style={{ filter: isDarkMode ? "invert(1)" : "none"}}/>
        </Button> */}
         {/* <Button
          onClick={handleQuickBill}
          
          className="food-card-text mode-button border-radius-10 cart-button final-button"
          sx={{
            padding: {
              sm: "5px 15px", md: "5px 4px", xs: "4px 10px", xl: "6px 8px", lg: "5px 15px",
            },
            fontSize: {
              sm: "15px", md: "13px", xs: "12px", xl: "14px", lg: "12px",
            },
            minWidth: {
              sm: "35px", md: "14px", xs: "12px", xl: "85px", lg: "60px",
            },
            background: isDarkMode ? '#8f8d8d' : '#D9D9D9',
           color: isDarkMode ? '#fff' : '#000000',
            fontWeight: "600",
          }}

        >
          Save & Ebill
        </Button> */}
        <Button
          onClick={handleQuickBill}
          disabled={!isOrderFoodsNotEmpty || isQuickOrder}
          className="food-card-text mode-button border-radius-10 cart-button final-button"
          sx={{
            padding: {
              sm: "5px 15px", md: "5px 4px", xs: "4px 10px", xl: "6px 8px", lg: "5px 15px",
            },
            fontSize: {
              sm: "15px", md: "13px", xs: "12px", xl: "14px", lg: "12px",
            },
            minWidth: {
              sm: "35px", md: "14px", xs: "12px", xl: "85px", lg: "60px",
            },
            background: isDarkMode ? '#8f8d8d' : '#D9D9D9',
           color: isDarkMode ? '#fff' : '#000000',
            fontWeight: "600",
          }}

        >
          {isQuickOrder ? 'Placing Order...' : 'Quick Order'} 
        </Button>

        <Modal
          open={openModal}

          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
        >
          <PopOverModal
            handleCloseModal={handleCloseModal}
            printText="Do you want to print Bill?"
            iconPath="../images/correct.png"
            onClickOne={handleNoQuickBill}
            onClickTwo={handlePrintingQuickBill}
            modalTopBorder="10px solid #47C01C"
            topHeading="Order Placed Successfully!"
            handleClose={handleClose}
            buttonTextTwo="Print Bill"
            buttonTextOne="No"
          />
        </Modal>
        <Box sx={{ display: 'none' }}>
          <Box ref={printableBillRef} >
            <QuickBill billId={billId} paymentMode={paymentMode} />
          </Box>
        </Box>
        {/* <Button
          onClick={handlePlaceOrder}
          disabled={!isOrderFoodsNotEmpty || isPlacingOrder}
          className="food-card-text mode-button border-radius-10 cart-button final-button"
          sx={{
            padding: {
              sm: "5px 15px",
              md: "5px 10px",
              xs: "4px 10px",
              xl: "6px 8px",
              lg: "5px 15px",
            },
            fontSize: {
              sm: "15px",
              md: "14px",
              xs: "12px",
              xl: "14px",
              lg: "12px",
            },
            minWidth: {
              sm: "15px",
              md: "14px",
              xs: "12px",
              xl: "85px",
              lg: "60px",
            },
            background: isDarkMode ? '#8f8d8d' : '#D9D9D9',
           color: isDarkMode ? '#fff' : '#000000',
            fontWeight: "600",
          }}
        >
         {isPlacingOrder ? 'Placing Order...' : 'Place Order'} 
        </Button> */}
        {/* <Button
          onClick={handleKot}
          disabled={!isOrderFoodsNotEmpty || iskotOrder}
          className="food-card-text mode-button border-radius-10 cart-button final-button"
          sx={{
            padding: {
              sm: "5px 15px",
              md: "5px 10px",
              xs: "4px 10px",
              xl: "6px 8px",
              lg: "5px 15px",
            },
            fontSize: {
              sm: "15px",
              md: "14px",
              xs: "12px",
              xl: "14px",
              lg: "12px",
            },
            minWidth: {
              sm: "15px",
              md: "14px",
              xs: "12px",
              xl: "85px",
              lg: "60px",
            },
            background: isDarkMode ? '#8f8d8d' : '#D9D9D9',
             color: isDarkMode ? '#fff' : '#000000',
            fontWeight: "600",
          }}
        >
         {iskotOrder ? 'Placing Kot...' : 'Kot'} 
        </Button>
        <Modal
          open={open}

          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
        >
          <PopOverModal
            handleClose={handleClose}
            iconPath="../images/correct.png"
            buttonTextTwo="Print Kot"
            modalTopBorder="10px solid #47C01C"
            topHeading="Order Placed Successfully!"
            buttonTextOne="No"
            printText="Do you want to print Token?"
            onClickOne={handleClose}
            onClickTwo={handlePrinting}

          />
        </Modal> */}
        {/* <Box sx={{ display: 'none' }}>

        <Box ref={printableKotRef} >
          <KotBill orderNo={orderNo}/>

          </Box>
        </Box> */}
      </Box>
    </Box>
  );


}

export default CartTable;