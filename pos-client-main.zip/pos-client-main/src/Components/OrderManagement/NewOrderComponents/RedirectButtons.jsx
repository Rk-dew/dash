import {
  Box,
  Button,
  Divider,
  Grid,
  Input,
  InputAdornment,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  FormHelperText,
} from "@mui/material";
import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useDrawer } from "../../Sidebar/DrawerContext";
import SearchIcon from "@mui/icons-material/Search";
import FastfoodIcon from '@mui/icons-material/Fastfood';
import { useDispatch, useSelector } from "react-redux";
import { useDarkMode } from "../../../Screens/DarkMode/DarkMode";
import { add } from "../../../Screens/store/foodSlice";
function RedirectButtons({ onAllClick, foodItems, onSearch }) {
  const { isDarkMode, toggleDarkMode, CustomTypography } = useDarkMode();
  const { submitButtonStyles, searchboxStyles , capitalizeFirstLetter , buttonDisabled , errorMessageStyles, listMainBox ,  inputStyles,  labelStyle, } = useDrawer();
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const location = useLocation();
  const currentUser = useSelector((state) => state.auth.user.data);
  const dispatch = useDispatch();



  const handleKOTButtonClick = () => {
    // Open the modal
    handleClickOpen();
  };
  const handleAllClick = () => {
    setSelectedCategory(null);
    onAllClick();
  };

  const newOrderButtons = [
    { text: "Order List", link: "/order-list" },
    {
      text: "Open Item",
      onClick: handleKOTButtonClick, 
    },
  ];

  const handleSearch = (query) => {
    setSearchQuery(query);
    onSearch(query);
  };

  const filteredFoodItems = foodItems.filter(
    (item) =>
      item.name && item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );


  const [formData, setFormData] = useState({
    foodName: "",
    price: "",
    storeId: currentUser.storeid,

  });
  const [errors, setErrors] = useState({
    foodName: "",
    price: "",
   });
   
   const validateField = (fieldName, value) => {
    let error = "";
    const capitalizedFieldName = capitalizeFirstLetter(fieldName);
    
    if (fieldName === "foodName") {
       if (!/^[A-Za-z\s]+$/.test(value)) {
        error = `${capitalizedFieldName} should only contain alphabets`;
      } else if (value.length > 50) {
        error = `${capitalizedFieldName} should not exceed 50 characters`;
      }
    }
    else if (fieldName === "price" ) {
      if (value <= 0) {
          error = `${capitalizedFieldName} should be a positive number`;
      }
    }
    setErrors(prevErrors => ({
      ...prevErrors,
      [fieldName]: error
    }));
    return error;
};

const handleInputChange = (e) => {
  const { name, value } = e.target;

  // Parse price to an integer if the name is "price"
  const parsedValue = name === "price" ? parseInt(value, 10) : value;

  setFormData({ ...formData, [name]: parsedValue });
  const error = validateField(name, parsedValue);
  setErrors({ ...errors, [name]: error });
};

const addfood = async (e) => {
  e.preventDefault();
  dispatch(add(formData))
  handleClickClose()


  setFormData(
    {
      foodName: "",
      price: "",
      storeId: currentUser.storeid,
    }
  )
};

const handleKeyPress = (e) => {
  if (e.key === 'Enter') {
    addfood(e);
}
}

const isSubmitDisabled = buttonDisabled(formData, errors);

 const [opens, setOpens] = React.useState(false);

  const handleClickOpen = () => {
    setOpens(true);
  };

  const handleClickClose = () => {
    setOpens(false);
    setFormData(
      {
        foodName: "",
        price: "",
        storeId: currentUser.storeid,
      })
  };
  return (
    <Box>
      <Grid
        container
        xl={8.6}
        lg={8.4}
        md={12}
        sm={12}
        xs={12}
        spacing={{
          xs: 0.6,
          sm: 1,
          md: 2,
          xl: 2,
        }}
        sx={{ mt: 1, minHeight: { lg: "9vh", sm: "7vh" } }}
      >
        <Grid item >
          <Button
            className="food-card-text mode-button border-radius-10 cart-button final-button"
            sx={{
              ...submitButtonStyles,
              marginRight: "0px",
              padding: {
                sm: "6px 25px",
                md: "8px 3vw",
                xs: "8px 7vw",
                xl: "10px 3vw",
                lg: "8px 3.2vw",
              },
              backgroundColor: isDarkMode ? "#5e5e5e" : "#47C01C",
              color: "#FFFFFF",
            }}
            onClick={handleAllClick}
          >
            All
          </Button>
        </Grid>
        {newOrderButtons.map((button, index) => (
          <Grid key={index} item>
            {button.onClick ? (
              <Button
              className="food-card-text mode-button border-radius-10 cart-button open-button"
              sx={{
                ...submitButtonStyles,
                marginRight: "0px",
                backgroundColor: isDarkMode ? "#5E5E5E" : "#28A497" , 
                color: isDarkMode ? "#fff" : "#fff",
                "&:hover": {
                  backgroundColor: isDarkMode ? "#fff" : "#38b5a8", 
                  color: isDarkMode ? "#000" : "#fff",
              },
              }}
              onClick={button.onClick}
            >
                {button.text}
              </Button>
            ) : (
              <Link to={button.link}>
                <Button
                  className="food-card-text mode-button border-radius-10 cart-button final-button"
                  sx={{
                    ...submitButtonStyles,
                    marginRight: "0px",
                    backgroundColor:
                      location.pathname === button.link
                        ? isDarkMode
                          ? "#5e5e5e"
                          : "#28A497"
                        : isDarkMode
                        ? "#5e5e5e"
                        : "#D9D9D9",
                    color:
                      location.pathname === button.link
                        ? isDarkMode
                          ? "#fff"
                          : "#fff"
                        : isDarkMode
                        ? "#fff"
                        : "#000000",
                  }}
                >
                  {button.text}
                </Button>
              </Link>
            )}
          </Grid>
        ))}

        <Grid
          xl={3.2}
          lg={3.2}
          md={4}
          sm={3.5}
          xs={8}
          item
          sx={{ width: "auto" }}
        >
          <Box
            sx={{
              padding: "6px 16px",
              display: "flex",
              alignItems: "center",
              borderRadius: "10px",
              backgroundColor: isDarkMode ? "#5e5e5e" : "#D9D9D9",
            }}
          >
            <InputAdornment position="start">
              <SearchIcon sx={{ color: isDarkMode ? "#fff" : "#000000" }} />
            </InputAdornment>
            <Divider
              orientation="vertical"
              sx={{ height: 24, mx: 1, backgroundColor: "#424242" }}
            />
            <Input
              fullWidth
              placeholder="Search"
              sx={{ color: isDarkMode ? "#fff" : "#000000" }}
              disableUnderline
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
            />
          </Box>
        </Grid>
        <Dialog 
              open={opens}
              onClose={handleClickClose}
              PaperProps={{
                sx: { backgroundColor: isDarkMode ? "#5E5E5E" : "#fff", p: 4, borderRadius: "10px" , },
              }}
            > 
             
              <DialogTitle
                className="food-card-text justify-all-center"
                sx={{...listMainBox , justifyContent:"left", maxWidth:"50%"}}
                
              >
                 <FastfoodIcon sx={{fontSize:"30px", marginRight:"10px"}}/>
                  Open Item
              </DialogTitle>
              <Box >
                <FormControl
                  sx={{ mt: 2 }}
                  fullWidth
                  error={!!errors.name}
                  variant="outlined"
                >
                  <CustomTypography className="food-card-text" sx={labelStyle}>
                    Item Name
                  </CustomTypography>
                
                  <Input
                    name="foodName"
                    fullWidth
                    value={formData.foodName}
                    onChange={handleInputChange}
                    onKeyPress={handleKeyPress}
                    sx={{...inputStyles , background: isDarkMode ? "#8F8D8D" : "#D9D9D9" , maxWidth:"100%"}}
                    className="food-card-text"
                    disableUnderline
                  >
                  </Input>
                  <FormHelperText
                    className="food-card-text"
                    sx={errorMessageStyles}
                  >
                    {errors.foodName}
                  </FormHelperText>
                </FormControl>
                <FormControl
                  sx={{ mt: 2 }}
                  fullWidth
                  error={!!errors.price}
                  variant="outlined"
                >
                  <CustomTypography className="food-card-text" sx={labelStyle}>
                   Price
                  </CustomTypography>
                  <Input
                     sx={{...inputStyles ,background: isDarkMode ? "#8F8D8D" : "#D9D9D9"  , maxWidth:"100%"}}
                    id="outlined-adornment-rate"
                    type="number"
                    onKeyPress={handleKeyPress}
                    name="price"
                    value={formData.price}
                    onChange={handleInputChange}
                    disableUnderline
                  />
                  <FormHelperText
                    className="food-card-text"
                    sx={errorMessageStyles}
                  >
                    {errors.price}
                  </FormHelperText>
                </FormControl>
              </Box>
              <DialogActions sx={{ display: "flex", justifyContent: "center" }}>
                <Button
                  type="submit"
                  className="food-card-text mode-button border-radius-10 cart-button final-button"
                  sx={{ ...submitButtonStyles, mt: 3 , padding:{sm: "8px 20px" ,  md: "8px 40px"  } , backgroundColor: isDarkMode ? "#8F8D8D" : "#28A497" ,   color: isSubmitDisabled ? "#fff" : (isDarkMode ? "#fff" : "#fff"), }}
                  onClick={addfood} disabled={isSubmitDisabled}
                >
                  Add Item
                </Button>
                <Button
                  type="submit"
                  className="food-card-text mode-button border-radius-10 cart-button final-button"
                  sx={{ ...submitButtonStyles, mt: 3 ,padding:{sm: "8px 20px" ,  md: "8px 40px"  }}}
                  onClick={handleClickClose} // Move the click event inside the form
                >
                  Cancel
                </Button>
              </DialogActions>
            </Dialog>
      </Grid>
    </Box>
  );
}

export default RedirectButtons;
