import {
  Box,
  Card,
  CardContent,
  CardActionArea,
  Divider,
} from "@mui/material";
import InventoryIcon from "@mui/icons-material/Inventory";
import ListIcon from "@mui/icons-material/List";
import { useDarkMode } from "../../Screens/DarkMode/DarkMode";
function CartInventoryManagment() {
  const { isDarkMode, toggleDarkMode , CustomTypography} = useDarkMode();
  return (
    <Box>
      <Box
        sx={{
          justifyContent: "center",
          display: "flex",
          backgroundColor: "#F1F4FFFF",
          height: "900px",
        }}
      >
        <Card
          variant="outlined"
          style={{
            backgroundColor: "#030e4f",
            width: "300px",
            marginTop: "350px",
            height: "300px",
          }}
        >
          <CardActionArea>
            <CardContent sx={{ textAlign: "center" }}>
              <CustomTypography>
                <InventoryIcon sx={{ fontSize: 80, color: "#f49f1c" }} />
              </CustomTypography>
              <Divider textAlign="right" color="#f49f1c" />
              <CustomTypography
                level="title-md"
                sx={{ color: " #f49f1c", fontSize: "30px" }}
              >
                Inventory
              </CustomTypography>
            </CardContent>
          </CardActionArea>
        </Card>
        <Card
          variant="outlined"
          style={{
            backgroundColor: "#E87A5D",
            width: "300px",
            textAlign: "center",
            marginLeft: "25px",
            marginTop: "350px",
            height: "300px",
          }}
        >
          <CardActionArea>
            <CardContent>
              <CustomTypography>
                <ListIcon
                  sx={{ fontSize: 80, marginTop: "-10px", color: "#3B5BA5" }}
                />
              </CustomTypography>
              <Divider textAlign="right" />
              <CustomTypography
                level="title-md"
                sx={{ color: " #F3B941", fontSize: "30px" }}
              >
                Inventory List
              </CustomTypography>
            </CardContent>
          </CardActionArea>
        </Card>
        {/* </Paper> */}
      </Box>
    </Box>
  );
}
export default CartInventoryManagment;
