import {
  Box,
  Button,
  Card,
  CardActionArea,
  CardActions,
  CardContent,
  CardMedia,
  Fab,
} from "@mui/material";
import React from "react";
import "./card.css";
import { Link } from "react-router-dom";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import StorefrontIcon from "@mui/icons-material/Storefront";
import AddBoxIcon from "@mui/icons-material/AddBox";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import InventoryIcon from "@mui/icons-material/Inventory";
import SideBar from "../Sidebar/SideBar";
import { useDarkMode } from "../../Screens/DarkMode/DarkMode";
function VendorDashboard() {
  const { isDarkMode, toggleDarkMode , CustomTypography} = useDarkMode();
  return (
    <Box sx={{ display: 'flex' }}>
    <SideBar />
    <Box component="main" sx={{ flexGrow: 1, p: 3, marginTop: '60px' }}>
      <Box
        pl={15}
        className="card-heading"
        sx={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "left",
          alignItems: "center",
          maxHeight: "70px"
          
        }}
      >
        <StorefrontIcon sx={{ fontSize: "37px", marginRight: "10px" }} />
        <p> Vendor Dashboard</p>
      </Box>

      <Box
        mt={10}
        sx={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "center",
          gap: "2",
          flexWrap: "wrap",
        }}
      >
        <Card className="card " sx={{ maxWidth: 345 }}>
          <CardActionArea>
            <CardMedia
              className="card1 justify-all-center"
              component="icon"
              height="140"
              sx={{ padding: "30px" }}
            >
              <AddBoxIcon sx={{ fontSize: "70px", color: "white" }} />
            </CardMedia>
            <Box
              className="forwrap"
              sx={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-between",
              }}
            >
              <CardContent>
                <CustomTypography
                  className="heading"
                  gutterBottom
                  variant="h5"
                  component="div"
                >
                  Add Vendor
                </CustomTypography>
              </CardContent>
              <CardActions>
                <Link to={"/addvendor"}>
                  <Button size="small" color="primary">
                    <Fab
                      sx={{ height: "40px", width: "40px" }}
                      color="primary"
                      aria-label="add"
                    >
                      <ArrowForwardIosIcon />
                    </Fab>
                  </Button>
                </Link>
              </CardActions>
            </Box>
          </CardActionArea>
        </Card>
        <Card className="card " sx={{ maxWidth: 345 }}>
          <CardActionArea>
            <CardMedia
              component="icon"
              height="140"
              className="card2 justify-all-center"
              sx={{ padding: "30px" }}
            >
              <AccountBalanceWalletIcon
                sx={{ fontSize: "70px", color: "white" }}
              />
            </CardMedia>
            <Box
              className="forwrap"
              sx={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-between",
              }}
            >
              <CardContent>
                <CustomTypography
                  className="heading"
                  gutterBottom
                  variant="h5"
                  component="div"
                >
                  Vendor Payment
                </CustomTypography>
              </CardContent>
              <CardActions>
                <Link to={"vendorpayment"}>
                  <Button size="small" color="primary">
                    <Fab
                      sx={{ height: "40px", width: "40px" }}
                      color="primary"
                      aria-label="add"
                    >
                      <ArrowForwardIosIcon />
                    </Fab>
                  </Button>
                </Link>
              </CardActions>
            </Box>
          </CardActionArea>
        </Card>
        <Card className="card " sx={{ maxWidth: 345 }}>
          <CardActionArea>
            <CardMedia
              component="icon"
              height="140"
              className="card3 justify-all-center"
              sx={{ padding: "30px" }}
            >
              <InventoryIcon sx={{ fontSize: "70px", color: "white" }} />
            </CardMedia>
            <Box
              className="forwrap"
              sx={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-between",
              }}
            >
              <CardContent>
                <CustomTypography
                  className="heading"
                  gutterBottom
                  variant="h5"
                  component="div"
                >
                  Vendor Inventory
                </CustomTypography>
              </CardContent>
              <CardActions>
                <Link to={"vendorinventory"}>
                  <Button size="small" color="primary">
                    <Fab
                      sx={{ height: "40px", width: "40px" }}
                      color="primary"
                      aria-label="add"
                    >
                      <ArrowForwardIosIcon />
                    </Fab>
                  </Button>
                </Link>
              </CardActions>
            </Box>
          </CardActionArea>
        </Card>
      </Box>
    </Box>
    </Box>
  );
}

export default VendorDashboard;
