import axios from "axios";
const API_URL=`https://apis.ubsbill.com/apptest/sys/Vendor`;
const currentuser = "sandip";
class VendorService{

    saveVendor(vendor)
    {
        return axios.post(API_URL+"/save",vendor);
    }

    getAllVendor(vendor)
    {
        return axios.get(API_URL+`/vendor/${currentuser.storeid}`,vendor);
    }

    updatevendor(vendor)
    {
        return axios.put(API_URL+"/updatevendor",vendor);
    }

    deleteVendor(vendor_id)
    {
        return axios.delete(API_URL+"/deletes/"+vendor_id);
    }

    getById(vendor_id)
    {
        return axios.get(API_URL+"/getVendorByID/"+vendor_id);
    }
}

export default new VendorService

