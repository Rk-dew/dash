import React, { useState } from "react";
import {
  Box,
  Button,
  Stack,
  FormControl,
  FormHelperText,
  Grid,
  Paper,
  Select,
  MenuItem,
  Input,
  styled,
  FormGroup,
  FormControlLabel,
  Checkbox,
} from "@mui/material";
import axios from "axios";
import BrunchDiningIcon from '@mui/icons-material/BrunchDining';
import { useErrorSnackbar } from "../../Screens/snackbar/ErrorSnackbarProvider";
import { useSuccessSnackbar } from "../../Screens/snackbar/SuccessSnackbarProvider";
import { useDrawer } from "../Sidebar/DrawerContext";
import { useSelector } from "react-redux";
import { useDarkMode } from "../../Screens/DarkMode/DarkMode";
function AddAddons() {
  const { isDarkMode, toggleDarkMode , CustomTypography} = useDarkMode();
  const currentUser = useSelector((state) => state.auth.user.data);
  const { showSuccessSnackbar } = useSuccessSnackbar();
  const { showErrorSnackbar } = useErrorSnackbar();
  const {
    labelStyle,
    inputStyles,
    errorMessageStyles,
    submitButtonStyles,
    formMainBox,
    formPaperStyles,
    capitalizeFirstLetter, buttonDisabled, selectStyles
  } = useDrawer();
  const formDataFields = [
    { name: "foodName", label: "Addon Name", type: "text" },
    { name: "foodCode", label: "Addon Code", type: "text" },
    { name: "price", label: "Price", type: "number" },
    {
      name: "category",
      label: "Category",
      type: "select",
      options: [
        { value: "Select Category", label: "Select Category" },
        { value: "Addon", label: "Addon" },

      ],
    },
    {
      name: 'subCategory', label: 'Sub Category', type: 'select', options: [
        { value: 'Select Sub Category', label: 'Select Sub Category' },
        { value: 'Addon', label: 'Addon' },
   
      ]
    },
    { name: "description", label: "Description", type: "text" },
    // { name: "image", label: "Select Image From Drive", type: "text" },
  ];
  const [formData, setFormData] = useState({
    ...formDataFields.reduce((acc, field) => ({ ...acc, [field.name]: "" }), {}),
    storeId: currentUser.storeid,
    createdBy: currentUser.username,
    updatedBy: currentUser.username,
  });

  const [errors, setErrors] = useState({
    ...formDataFields.reduce((acc, field) => ({ ...acc, [field.name]: "" }), {})

  });

  const validateField = (fieldName, value) => {
    let error = "";
    const numberRegex = new RegExp(/^\d{1,10}$/);
    const capitalizedFieldName = capitalizeFirstLetter(fieldName);

    if (value.trim() === "") {
      error = `${capitalizedFieldName} is Mandatory`;
    }

    if (fieldName === "price") {
      if (!numberRegex.test(value)) {
        error = `${capitalizedFieldName} should not be a Negative`;
      }
      else if (parseFloat(value) === 0) {
        error = `${capitalizedFieldName} should not be 0`;
      } else if (value.length > 5) {
        error = `${capitalizedFieldName} should not exceed 5 characters`;
      }
    }

    if (fieldName === "foodName") {
      if (value.length > 25) {
        error = `${capitalizedFieldName} should not exceed 25 characters`;
      }
    }

    if(fieldName === "category"){
      if (value === "Select Category") {
        error = `${capitalizedFieldName} Please Select the category`;
      }
    }

    if(fieldName === "subCategory"){
      if (value === "Select Sub Category") {
        error = `${capitalizedFieldName} Please Select the Sub Category`;
      }
    }

    return error;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    if (errors[name] && !validateField(name, value)) {
      setErrors({ ...errors, [name]: "" });
    }
  };



  const handleAddon = async (e) => {
    e.preventDefault();

    if (Object.values(errors).every((error) => error === "")) {
      try {
        const response = await axios.post("https://apis.ubsbill.com/apptest/v2/food/", formData , {
          headers: {
              'Authorization': `Bearer ${currentUser.token}`, 
              'Content-Type': 'application/json'
          }
      });
        if (response.data.status === true) {
          showSuccessSnackbar("Form Submit Successfull !");
          setFormData({
            ...formDataFields.reduce((acc, field) => ({ ...acc, [field.name]: "" }), {}),
            storeId: currentUser.storeid,
            createdBy: currentUser.username,
            updatedBy: currentUser.username,
          });
        }
        else {
          showErrorSnackbar(response.data.message);
          setFormData({
            ...formDataFields.reduce((acc, field) => ({ ...acc, [field.name]: "" }), {}),
            storeId: currentUser.storeid,
            createdBy: currentUser.username,
            updatedBy: currentUser.username,
          });
        }

      } catch (error) {
        showErrorSnackbar("Form Submit Failed");
        setFormData({
          ...formDataFields.reduce((acc, field) => ({ ...acc, [field.name]: "" }), {}),
          storeId: currentUser.storeid,
          createdBy: currentUser.username,
          updatedBy: currentUser.username,
        });
      }
    }
  };

  //it will check checkbox
  const [isChecked, setChecked] = useState(false);
  const handleCheckboxChange = (event) => {
    setChecked(event.target.checked);
  };

  const isSubmitDisabled = buttonDisabled(formData, errors);


  return (
    <Box component="main" sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <Paper elevation={12} sx={formPaperStyles}>
        <Grid container spacing={1} sx={{ mb: 4 }}>
          <Grid item>
            <Box
              display="flex"
              alignItems="center"
              bgcolor="primary.light"
              p={1}
              sx={formMainBox}
            >
              <BrunchDiningIcon fontSize="large" />
              <span style={{ marginLeft: "8px" }}>Add Addons</span> {/* Text */}
            </Box>
          </Grid>
        </Grid>

        {Array.from({ length: 4 }).map((_, index) => (
          <Stack
            key={index}
            spacing={4}
            direction={{
              xs: "column",
              sm: "row",
              md: "row",
              lg: "row",
              xl: "row",
            }}
            sx={{ marginBottom: 1 }}
          >
            {formDataFields
              .slice(index * 2, index * 2 + 2)
              .map((formDataItem, innerIndex) => (
                <FormControl
                  key={innerIndex}
                  fullWidth
                  error={!!errors[formDataItem.name]}
                  variant="outlined"
                >
                  <CustomTypography
                    htmlFor={`outlined-adornment-${formDataItem.name}`}
                    className="food-card-text"
                    sx={labelStyle}
                  >
                    {formDataItem.label}
                  </CustomTypography>

                  {formDataItem.type === 'select' ? (
                    <Select
                      labelId={`select-${formDataItem.name}`}
                      id={`select-${formDataItem.name}`}
                      name={formDataItem.name}
                      value={
                        formData[formDataItem.name] ||
                        formDataItem.options[0].label
                      }
                      onChange={handleInputChange}
                      sx={selectStyles}
                    >
                     {formDataItem.options.map((option, optionIndex) => (
                        <MenuItem key={optionIndex} value={option.value}>
                          {option.label}
                        </MenuItem>
                      ))}
                    </Select>
             
                  ) : formDataItem.type === "file" ? (
                    <Input
                      sx={inputStyles}
                      type="file"
                      name={formDataItem.name}
                      value={formData[formDataItem.name]}
                      onChange={handleInputChange}
                      disableUnderline
                    />

                  ) : (
                    <Input
                      sx={inputStyles}
                      type={formDataItem.type}
                      name={formDataItem.name}
                      value={formData[formDataItem.name]}
                      onChange={handleInputChange}
                      disableUnderline

                    />
                  )}

                  <FormHelperText
                    className="food-card-text"
                    sx={errorMessageStyles}
                  >
                    {errors[formDataItem.name]}
                  </FormHelperText>
                </FormControl>

              ))}
          </Stack>
        ))}
        {/* <Box style={{ display: "flex", alignItems: "center" }}>
          <FormGroup >
            <FormControlLabel control={<Checkbox checked={isChecked} onChange={handleCheckboxChange} />} />
          </FormGroup>
          <CustomTypography className="food-card-text" sx={{ fontWeight: "400", fontSize: "14px", marginLeft: "-10px" }}>Please Check This Box To Update Current Changes</CustomTypography>
        </Box> */}
        <Box sx={{ display: "flex", justifyContent: "center", mt: 3 }}>
          <Button onClick={handleAddon}
            className="food-card-text mode-button border-radius-10 cart-button final-button"
            sx={submitButtonStyles} disabled={isSubmitDisabled}
          >
            Submit
          </Button>
        </Box>
      </Paper>
    </Box>
  );
}
export default AddAddons;