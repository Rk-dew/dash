import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  CircularProgress,
  Grid,
  Input,
  LinearProgress,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  Pagination,
  Popover,
} from "@mui/material";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Pie,
  AreaChart,
  Area,
  Cell,
} from "recharts";

import InventoryIcon from "@mui/icons-material/Inventory";
import { PieChart } from "@mui/x-charts/PieChart";
import { useDrawer } from "../Sidebar/DrawerContext";
import { useTableContext } from "../../Screens/tableContext/TableContext";
import StarIcon from "@mui/icons-material/Star";
import EqualizerIcon from "@mui/icons-material/Equalizer";
import { useDarkMode } from "../../Screens/DarkMode/DarkMode";
import { useSelector } from "react-redux";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import axios from "axios";
import LocalDiningIcon from "@mui/icons-material/LocalDining";

const itemsPerPage = 5;
const SalesReport = () => {
  const [inventoryListData, SetInventoryListData] = useState([]);
  const [totalSales, setTotalSales] = useState(0); // Declare totalSales in state
  const { dateFieldStyles, fromAndToTextStyles , reportscardstyle } = useDrawer();

  const currentUser = useSelector((state) => state.auth.user.data);
  const { isDarkMode, CustomTypography } = useDarkMode();
  const [loading, setLoading] = useState(false);
  const {
    pdfAndExcelButtonStyles,
    listMainGridStyles,
    tableCellStyles,
    contentTableRowStyles,
    tableHeadStyles,
    listMainBox,
    listIconStyles,
    spaceBetweenTopComponent,
  } = useDrawer();
  const { renderStyledCell, getFontWeight } = useTableContext();
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);
  const [customFromDate, setCustomFromDate] = useState("");
  const [customToDate, setCustomToDate] = useState("");
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);

  const handleStartDateChange = (date) => {
    setStartDate(date);
  };

  const handleEndDateChange = (date) => {
    setEndDate(date);
  };

  const resetCustomDateRange = () => {
    setCustomFromDate("");
    setCustomToDate("");
  };

  useEffect(() => {
    resetCustomDateRange();
  }, []);


  //Difference in amount is visible in popover
  const [anchorEl, setAnchorEl] = useState(null);

  const handlePopoverOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  const tableHeaders = [
    { label: "SR No." },
    { label: "Product Name" },
    { label: "Quantity" },
    { label: "Total Cost" },
  ];




  const formatDate = (date) => {
    const year = date.getFullYear();
    let month = date.getMonth() + 1;
    let day = date.getDate();

    month = month < 10 ? "0" + month : month;
    day = day < 10 ? "0" + day : day;

    return `${year}-${month}-${day}`;
  };

  //to set and get days in graph
  const getDayOfWeek = (date) => {
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    return days[date.getDay()];
  };

   // Set initial range state to 'Daily'

  const [range, setRange] = useState("Daily");
  useEffect(() => {
    handleButtonClick("Daily");
  }, []);



  //To get currentdate and set to fromdate and todate
  const filterDailyRecords = () => {
    const today = new Date();
    const fromDateFormatted = formatDate(today);
    const toDateFormatted = formatDate(today);
    setFromDate(fromDateFormatted);
    setToDate(toDateFormatted);
  };
 
 
   //To get current week start date and last date  so we will get weekly records while 
   //passing fromdate and todate in url
  const fetchWeeklyRecords = () => {
    const today = new Date();
    const currentDay = today.getDay(); 
    const sundayDate = new Date(today); 
    sundayDate.setDate(today.getDate() - currentDay); 

    const saturdayDate = new Date(today); 
    saturdayDate.setDate(today.getDate() + (6 - currentDay)); 

    const fromDateFormatted = formatDate(sundayDate);
    const toDateFormatted = formatDate(saturdayDate);

    setFromDate(fromDateFormatted);
    setToDate(toDateFormatted);
  };

  //To get currentmonth start and end date and set to fromdate and todate
  const filterMonthlyRecords = () => {
    const today = new Date();
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const lastDayOfMonth = new Date(
      today.getFullYear(),
      today.getMonth() + 1,
      0
    );
    const fromDateFormatted = formatDate(firstDayOfMonth);
    const toDateFormatted = formatDate(lastDayOfMonth);
    setFromDate(fromDateFormatted);
    setToDate(toDateFormatted);
  };

  //To get current year start and end date and set to fromdate and todate
  const filterYearlyRecords = () => {
    const today = new Date();
    const firstDayOfYear = new Date(today.getFullYear(), 0, 1);
    const lastDayOfYear = new Date(today.getFullYear(), 11, 31);
    const fromDateFormatted = formatDate(firstDayOfYear);
    const toDateFormatted = formatDate(lastDayOfYear);
    setFromDate(fromDateFormatted);
    setToDate(toDateFormatted);
  };

  //to get customfrom and to date and sate to fromdate and todate state
  const filterCustomRecords = () => {
    setFromDate(customFromDate);
    setToDate(customToDate);
  };

  //function when we click any button from daily , weekly , year , month , custom
  //for each button we will call following api
  const handleButtonClick = (selectedRange) => {
    setRange(selectedRange);
    switch (selectedRange) {
      case "Daily":
        resetCustomDateRange();
        fetchDailyData();
        filterDailyRecords();
        fetchProductData();
        break;
      case "Monthly":
        resetCustomDateRange();
        fetchMonthlyData();
        filterMonthlyRecords();
        fetchProductData();
        break;
      case "Weekly":
        resetCustomDateRange();

        fetchWeeklyRecords();
        fetchProductData();
        break;
      case "Yearly":
        resetCustomDateRange();
        fetchYearlyData();
        filterYearlyRecords();
        fetchProductData();
        break;
      case "Custom":
        fetchCustomData();
        fetchMonthlyData();
        filterCustomRecords();
        fetchProductData();
        break;
      default:
        console.error("Invalid range selected");
    }
  };

  //if custom date we provide then accordingly handleButtonClick custom functions will call only
  useEffect(() => {
    if (customFromDate && customToDate) {
      handleButtonClick("Custom");
    }
  }, [customToDate, customFromDate, range]); 

  //In barchart on  x axis which content will visible that we provided below , check fillMissingData function which will set xaxis info
  const getXAxisTickFormatter = (range) => {
    switch (range) {
      case "Daily":
        return (hour) => hour;
      case "Weekly":
        return (day) => day;
      case "Monthly":
        return (month) => month;
      case "Yearly":
        return (year) => year;
      default:
        return null;
    }
  };

  const [customData, setCustomData] = useState([]);

  const fetchCustomData = async () => {
    try {
     
      const response = await fetch(
        `https://apis.ubsbill.com/apptest/v2/balance/store/${currentUser.storeid}?page=0&size=50000&startDate=${customFromDate}&endDate=${customToDate}`,{
          headers: {
              'Authorization': `Bearer ${currentUser.token}`, 
              'Content-Type': 'application/json'
          }
      }
      );
      const responseData = await response.json();

      // Extract the balance data from the response
      const balanceData = responseData.data.balance;

     
      let totalCash = 0;
      let totalCard = 0;
      let totalUpi = 0;

      // To find total cash , card , upi  
      balanceData.forEach((entry) => {
        totalCash += parseFloat(entry.sales.cash || 0);
        totalCard += parseFloat(entry.sales.card || 0);
        totalUpi += parseFloat(entry.sales.upi || 0);
      });

      // Build new json which will have totalCash , totalCard , totalUpi
      const customData = {
        cash: totalCash.toFixed(2),
        card: totalCard.toFixed(2),
        upi: totalUpi.toFixed(2),
      };

    
      setCustomData(customData);
    } catch (error) {
      console.error("Error fetching custom data:", error);
    }
  };

  const [dailyData, setDailyData] = useState([]);
  const [totalDailySales, setTotalDailySales] = useState({
    cash: 0,
    card: 0,
    upi: 0,
  });
  
  //it will fetch daily data and set in 3 state and that 3 state will use for Barchart , piechart and To find totalsales 
  const fetchDailyData = async () => {
    try {
      const response = await fetch(
        `https://apis.ubsbill.com/apptest/v2/report/totalPaymentMode/${currentUser.storeid}` ,{
          headers: {
              'Authorization': `Bearer ${currentUser.token}`, 
              'Content-Type': 'application/json'
          }
      }
      );
      const responseData = await response.json();

      const dailyData = [];
      let totalCash = 0;
      let totalUPI = 0;
      let totalCard = 0;

      for (let hour = 0; hour < 24; hour++) {
        const hourData = responseData.data[`hour_${hour}`][hour];
        if (
          hourData &&
          (hourData.cash !== null ||
            hourData.upi !== null ||
            hourData.card !== null)
        ) {
          dailyData.push({
            hour,
            cash: hourData.cash || 0,
            upi: hourData.upi || 0,
            card: hourData.card || 0,
          });

         
          totalCash += hourData.cash || 0;
          totalUPI += hourData.upi || 0;
          totalCard += hourData.card || 0;
        }
      }
     
    
      setDailyData(dailyData);
      
      let totalDailyCash = 0;
      let totalDailyUPI = 0;
      let totalDailyCard = 0;

      // Iterate over the dailyData array to get amounts
      dailyData.forEach((hourData) => {
        totalDailyCash += hourData.cash || 0;
        totalDailyUPI += hourData.upi || 0;
        totalDailyCard += hourData.card || 0;
      });

      // Create a new JSON object with total cash, card, and UPI amounts
      const totalSalesData = {
        cash: totalDailyCash,
        upi: totalDailyUPI,
        card: totalDailyCard,
      };

    
      setTotalDailySales(totalSalesData);

     
      const totalSalesAmount = totalCash + totalUPI + totalCard;
     
      setTotalSales(
        totalSalesAmount.toLocaleString("en-IN", {
          style: "currency",
          currency: "INR",
        })
      );
    } catch (error) {
      console.error("Error fetching daily data:", error);
    }
  };

  useEffect(() => {
    if (range === "Daily") {
      fetchDailyData();
    }
  }, [range]);

  const [weeklyData, setWeeklyData] = useState([]);
  const [totalWeeklySales, setTotalWeeklySales] = useState({
    cash: 0,
    card: 0,
    upi: 0,
  });

//it will fetch weekly data and set in 3 state and that 3 state will use for Barchart , piechart and To find totalsales 
  const fetchWeeklyData = async () => {
    const today = new Date();
    const currentDay = today.getDay(); 
    const currentDayName = getDayOfWeek(today); 

   //to get startdate and enddate of week
    const daysToAdd = currentDay === 0 ? 0 : 7 - currentDay;
    const sunday = new Date(today);
    sunday.setDate(today.getDate() - currentDay);
    const saturday = new Date(today);
    saturday.setDate(today.getDate() + daysToAdd);

    const fromDate = formatDate(sunday);
    const toDate = formatDate(saturday);

    try {
      const response = await fetch(
        `https://apis.ubsbill.com/apptest/v2/balance/store/${currentUser.storeid}?page=0&size=50000&startDate=${fromDate}&endDate=${toDate}`,{
          headers: {
              'Authorization': `Bearer ${currentUser.token}`, 
              'Content-Type': 'application/json'
          }
      }
      );
      const responseData = await response.json();
      const weeklySales = responseData.data.balance.map((item) => ({
        day: getDayOfWeek(new Date(item.date)),
        cash: item.sales.cash,
        upi: item.sales.upi,
        card: item.sales.card,
      }));
      console.log("weeklySales", weeklySales);
      setWeeklyData(weeklySales);

      // Calculate total weekly sales
      let totalCash = weeklySales
        .reduce((total, item) => total + item.cash, 0)
        .toFixed(2);
      let totalCard = weeklySales
        .reduce((total, item) => total + item.card, 0)
        .toFixed(2);
      let totalUpi = weeklySales
        .reduce((total, item) => total + item.upi, 0)
        .toFixed(2);

      // Set total weekly sales in state
      setTotalWeeklySales({ cash: totalCash, card: totalCard, upi: totalUpi });
     

      let totalSales = weeklySales.reduce(
        (total, item) => total + item.cash + item.card + item.upi,
        0
      );
      setTotalSales(
        totalSales.toLocaleString("en-IN", {
          style: "currency",
          currency: "INR",
        })
      );
      

     
    } catch (error) {
      console.error("Error fetching weekly data:", error);
    }
  };

  useEffect(() => {
    if (range === "Weekly") {
      fetchWeeklyData();
    }
  }, [range]);

  const [monthlyData, setMonthlyData] = useState([]);
  const [totalMonthlySales, setTotalMonthlySales] = useState({
    cash: 0,
    card: 0,
    upi: 0,
  });
  const [differenceInAmount, setDifferenceInAmount] = useState("");
  const [differenceInPercentage, setDifferenceInPercentage] = useState("");
  const fetchMonthlyData = async () => {
    try {
      const currentYear = new Date().getFullYear();
      const response = await fetch(
        `https://apis.ubsbill.com/apptest/v2/report/totalWithMonth?storeId=${currentUser.storeid}&year=${currentYear}`,{
          headers: {
              'Authorization': `Bearer ${currentUser.token}`, 
              'Content-Type': 'application/json'
          }
      }
      );
      const responseData = await response.json();

      const months = [
        "01",
        "02",
        "03",
        "04",
        "05",
        "06",
        "07",
        "08",
        "09",
        "10",
        "11",
        "12",
      ];
      const fetchedMonthlyData = months.map((month) => ({
        month: getMonthName(month),
        cash: responseData.data[month]?.cash || 0,
        upi: responseData.data[month]?.upi || 0,
        card: responseData.data[month]?.card || 0,
      }));
      
      setMonthlyData(fetchedMonthlyData);

      // Set the totalMonthlySales state with the data of the current month and that we will pass to pie chart
      const currentMonth = new Date().getMonth() + 1; // Get the current month (1-12)
      const currentMonthData = fetchedMonthlyData.find((monthData) => {
        return monthData.month === getMonthName(currentMonth);
      });

      

      setTotalMonthlySales({
        cash: currentMonthData?.cash || 0,
        card: currentMonthData?.card || 0,
        upi: currentMonthData?.upi || 0,
      });
     

      
      const totalSaless =
        (currentMonthData?.cash || 0) +
        (currentMonthData?.card || 0) +
        (currentMonthData?.upi || 0);
      setTotalSales(
        totalSaless.toLocaleString("en-IN", {
          style: "currency",
          currency: "INR",
        })
      );

     

      
      const previousMonthIndex = currentMonth - 2 >= 0 ? currentMonth - 2 : 11;

    
      const previousMonthData = fetchedMonthlyData[previousMonthIndex];
      const totalSalesPreviousMonth =
        (previousMonthData?.cash || 0) +
        (previousMonthData?.card || 0) +
        (previousMonthData?.upi || 0);

      // Calculate the difference between current month sales and previous month sales
      const difference = totalSaless - totalSalesPreviousMonth;

      // Calculate the percentage change
      const percentageChange = (
        (difference / totalSalesPreviousMonth) *
        100
      ).toFixed(2);

      // Add a plus sign for positive differences and a minus sign for negative differences
      const signedDifference =
        difference >= 0
          ? `+${difference.toLocaleString("en-IN", {
              style: "currency",
              currency: "INR",
            })}`
          : difference.toLocaleString("en-IN", {
              style: "currency",
              currency: "INR",
            });

    
      const formattedPercentageChange = `${percentageChange}%`;

      // Set the difference in amount state
      setDifferenceInAmount(signedDifference);

      // Set the difference in percentage state
      setDifferenceInPercentage(formattedPercentageChange);
    } catch (error) {
      console.error("Error fetching monthly data:", error);
    }
  };

  const getMonthName = (monthNumber) => {
    const monthNames = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];
    return monthNames[parseInt(monthNumber) - 1] || "";
  };

  useEffect(() => {
    if (range === "Monthly" || range === "Custom") {
      fetchMonthlyData();
    }
  }, [range]);

  const [yearlyData, setYearlyData] = useState([]);
  const [totalYearlySales, setTotalYearlySales] = useState({
    cash: 0,
    card: 0,
    upi: 0,
  });

  const fetchYearlyData = async () => {
    try {
      const currentYear = new Date().getFullYear();
      const startYear = currentYear - 4;
      const response = await fetch(
        `https://apis.ubsbill.com/apptest/v2/report/totalWithYear?storeId=1&startYear=${startYear}&endYear=${currentYear}`,{
          headers: {
              'Authorization': `Bearer ${currentUser.token}`, 
              'Content-Type': 'application/json'
          }
      }

      );
      const responseData = await response.json();

      const fetchedYearlyData = responseData.data.map((item) => ({
        year: item.year.toString(),
        cash: parseFloat(item.cash || 0).toFixed(2),
        upi: parseFloat(item.upi || 0).toFixed(2),
        card: parseFloat(item.card || 0).toFixed(2),
      }));

      setYearlyData(fetchedYearlyData);
    

      //this is for current year which we will use in piechart
      const currentYearData = fetchedYearlyData.find(
        (yearData) => yearData.year === currentYear.toString()
      );

      setTotalYearlySales({
        cash: currentYearData?.cash || 0,
        card: currentYearData?.card || 0,
        upi: currentYearData?.upi || 0,
      });

      // Calculate the total yearly sales for the current year
      const totalSalesCurrentYear =
        (parseFloat(currentYearData?.cash) || 0) +
        (parseFloat(currentYearData?.card) || 0) +
        (parseFloat(currentYearData?.upi) || 0);
      // Set the total sales for the current year
      setTotalSales(
        totalSalesCurrentYear.toLocaleString("en-IN", {
          style: "currency",
          currency: "INR",
        })
      );

     

    
      const currentYearIndex = fetchedYearlyData.findIndex(
        (yearData) => yearData.year === currentYear.toString()
      );
      const previousYearIndex = currentYearIndex - 1;

      const previousYearData = fetchedYearlyData[previousYearIndex];

      // Calculate the total sales for the previous year
      const totalSalesPreviousYear =
        parseFloat(previousYearData?.cash || 0) +
        parseFloat(previousYearData?.card || 0) +
        parseFloat(previousYearData?.upi || 0);

      const differenceInAmount = totalSalesCurrentYear - totalSalesPreviousYear;

      // Calculate the difference in percentage
      const differenceInPercentage = (
        (differenceInAmount / totalSalesPreviousYear) *
        100
      ).toFixed(2);
      
      setDifferenceInAmount(
        differenceInAmount.toLocaleString("en-IN", {
          style: "currency",
          currency: "INR",
        })
      );

     
      setDifferenceInPercentage(`${differenceInPercentage}%`);
    } catch (error) {
      console.error("Error fetching yearly data:", error);
    }
  };

  useEffect(() => {
    if (range === "Yearly") {
      fetchYearlyData();
    }
  }, [range]);

  const fillMissingData = (data, range) => {
    if (range === "Monthly") {
      const filledData = [];
      const months = [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec",
      ];
      for (let i = 0; i < months.length; i++) {
        const monthData = data.find((item) => item.month === months[i]);
        filledData.push(
          monthData || { month: months[i], cash: 0, upi: 0, card: 0 }
        );
      }
      return filledData;
    } else if (range === "Weekly" || range === "Daily") {
      const filledData = [];
      if (range === "Weekly") {
        const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
        for (let i = 0; i < days.length; i++) {
          const dayData = data.find((item) => item.day === days[i]);
          filledData.push(
            dayData || { day: days[i], cash: 0, upi: 0, card: 0 }
          );
        }
      } else if (range === "Daily") {
        for (let hour = 1; hour <= 24; hour++) {
          // For hour 24, retrieve data for hour 24 or hour 0 if hour 24 is not found
          const hourData =
            hour === 24
              ? data.find((item) => item.hour === 24) ||
                data.find((item) => item.hour === 0)
              : data.find((item) => item.hour === hour);
          filledData.push(hourData || { hour, cash: 0, upi: 0, card: 0 });
        }
      }
      return filledData;
    } else if (range === "Yearly") {
      const filledData = [];
      const years = ["2020", "2021", "2022", "2023", "2024"]; // Example years
      for (let i = 0; i < years.length; i++) {
        const yearData = data.find((item) => item.year === years[i]);
        filledData.push(
          yearData || { year: years[i], cash: 0, upi: 0, card: 0 }
        );
      }
      return filledData;
    }
    return [];
  };

 

 

  
 

  const [mostSellingFood, setMostSellingFood] = useState("");

  useEffect(() => {
    axios
      .get(
        `https://apis.ubsbill.com/apptest/v2/bill/mostSellingFood/${currentUser.storeid}` ,
        {
          headers: {
              'Authorization': `Bearer ${currentUser.token}`, 
              'Content-Type': 'application/json'
          }
      }
      )
      .then((response) => {
        const mostSellingFoodData = response.data.data[0];
        const firstFoodName = mostSellingFoodData["foodName "] || "";
        setMostSellingFood(firstFoodName);
      })
      .catch((error) => {
        console.error("Error fetching most selling food data:", error);
      });
  }, [currentUser]);


  //it will usefull for table
  const [productListData, SetProductListData] = useState([]);
  const fetchProductData = async () => {
   
    setLoading(true);
    try {
      const response = await fetch(
        `https://apis.ubsbill.com/apptest/v2/report/mostSellingFoodByDate/${currentUser.storeid}?startDate=${fromDate}&endDate=${toDate}`,{
          headers: {
              'Authorization': `Bearer ${currentUser.token}`, 
              'Content-Type': 'application/json'
          }
      }
      );
      const responseData = await response.json();
      SetProductListData(responseData.data);
    } catch (error) {
    
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProductData();
  }, []);

  const [page, setPage] = useState(1);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const startIndex = (page - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;

  return (
    <Box component="main">
      <Grid container spacing={2}>
      <Grid
        item
        xs={12}
        sx={{
          ...listMainGridStyles,
          display: "flex",
          flexDirection: { md: "row", sm: "column", xs: "column" },
        }}
      >
        <Box display="flex" bgcolor="primary.light" sx={listMainBox}>
          <InventoryIcon sx={listIconStyles} />
          <Typography variant="span" sx={{ ml: "8px" }}>
            Report
          </Typography>
        </Box>

        <Box container spacing={2}
          sx={{
            ...spaceBetweenTopComponent,
            display: "flex",
            flexDirection: { sm: "row", xs: "column" },
            marginLeft:{ sm: "0px", md: "auto" },
          }}
        >
          <Box sx={{ display: "flex" , mb: {sm: "0px" , xs:"10px", } }}>
            <Button
              to="/inventory-management-dashboard/add-inventory"
              className={`food-card-text mode-button border-radius-10 cart-button final-button ${
                range === "Daily" ? "selected" : ""
              }`}
              sx={pdfAndExcelButtonStyles}
              onClick={() => handleButtonClick("Daily")}
            >
              Daily
            </Button>
            <Button
              className={`food-card-text mode-button border-radius-10 cart-button final-button ${
                range === "Weekly" ? "selected" : ""
              }`}
              sx={pdfAndExcelButtonStyles}
              onClick={() => handleButtonClick("Weekly")}
            >
              Weekly
            </Button>
            <Button
              className={`food-card-text mode-button border-radius-10 cart-button final-button ${
                range === "Monthly" ? "selected" : ""
              }`}
              sx={pdfAndExcelButtonStyles}
              onClick={() => handleButtonClick("Monthly")}
            >
              Monthly
            </Button>
            <Button
              className={`food-card-text mode-button border-radius-10 cart-button final-button ${
                range === "Yearly" ? "selected" : ""
              }`}
              sx={pdfAndExcelButtonStyles}
              onClick={() => handleButtonClick("Yearly")}
            >
              Yearly
            </Button>
          </Box>
          <Grid container spacing={2} sx={{}}>
            <Grid item xs={12} sm={12} md={12} lg={12}>
              <Box
                bgcolor="#D9D9D9"
                sx={{
                  fontWeight: "600",
                  borderRadius: 1,
                  height: "100%",
                  padding: "4px",
                  alignItems: "center",
                  display: "flex",
                  justifyContent: "space-evenly",
                  backgroundColor: isDarkMode ? "#7a7a7a" : "#D9D9D9",
                  color: isDarkMode ? "#fff" : "#000",
                }}
              >
                <Input
                  fullWidth
                  type="date"
                  sx={{ ...dateFieldStyles, marginRight: "10px" }}
                  value={customFromDate}
                  onChange={(e) => {
                    setCustomFromDate(e.target.value);
                    if (e.target.value && customToDate) {
                      handleButtonClick("Custom");
                    }
                  }}
                  disableUnderline
                />
                <CustomTypography>-</CustomTypography>
                <Input
                  fullWidth
                  type="date"
                  sx={{ ...dateFieldStyles, marginRight: "6px" }}
                  value={customToDate}
                  onChange={(e) => {
                    setCustomToDate(e.target.value);
                    if (customFromDate && e.target.value) {
                      handleButtonClick("Custom");
                    }
                  }}
                  disableUnderline
                />
              </Box>
            </Grid>
          </Grid>
        </Box>
      </Grid>
      </Grid>

      <Grid container  xs={12} md={10} lg={9} xl={9} spacing={3} mt={1} justifyContent="space-evenly">
        {/* Bar Chart */}
        <Grid item xs={12} md={6} >
          <Paper
            sx={{
              p: {sm: 2 , xs: 1},
              position: "relative",
              zIndex: 1,
              display: "flex",
              justifyContent: "space-between",
              alignItems:"center",
              background: isDarkMode ? "#7A7A7A" : "#ddf2d5",
            }}
            elevation={3}
            onMouseEnter={handlePopoverOpen}
            onMouseLeave={handlePopoverClose} 
          >
            <div>
              <CustomTypography
                className="food-card-text"
                sx={{...reportscardstyle, display: "flex", alignItems: "center" }}
              >
                <TrendingUpIcon
                  style={{
                    fontSize: "2rem",
                    marginRight: "0.5rem",
                    color: "green",
                  }}
                />{" "}
                Total Sales
              </CustomTypography>
            </div>
            <div  style={{ display: "flex" }}>
              <CustomTypography sx={{...reportscardstyle, }} className="food-card-text">
                {totalSales}
              </CustomTypography>{" "}
              {range &&
                range !== "Weekly" &&
                (range === "Monthly" || range === "Yearly") && (
                  <Typography
                 
                    className="food-card-text"
                    sx={{...reportscardstyle,
                      color: isDarkMode
                        ? "#fff"
                        : differenceInAmount.includes("-")
                        ? "#ff0000"
                        : "#30ba30",
                    }}
                  >
                    ({differenceInPercentage})
                  </Typography>
                )}
              {(range === "Monthly" || range === "Yearly") && (   <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handlePopoverClose}
         sx={{
          
          ml:"20vw",
          zIndex: 2, // Ensure Popover has a higher z-index than Paper
        }}
      >
        <Typography>{differenceInAmount}</Typography>
      </Popover> ) }
            </div>
          </Paper>
        </Grid>
        
      
        <Grid item xs={12} md={6}>
          <Paper
            sx={{
               p: {sm: 2 , xs: 1},
              display: "flex",
              justifyContent: "space-between",
              alignItems:"center",
              background: isDarkMode ? "#7A7A7A" : "#faeca0",
            }}
            elevation={3}
          >
            <div>
              <CustomTypography
                className="food-card-text"
                sx={{...reportscardstyle,  display: "flex", alignItems: "center"  }}
              >
                <LocalDiningIcon
                  style={{ fontSize: "2rem", marginRight: "0.5rem" }}
                />{" "}
                Most Selling Food
              </CustomTypography>
            </div>
            <div>
            <CustomTypography
      sx={{
        ...reportscardstyle,
        maxWidth: {lg : '140px' , }, // Set your desired max width here
        overflow: 'hidden',
        whiteSpace: 'nowrap',
        textOverflow: 'ellipsis',
        '&:hover': {
          whiteSpace: 'normal',
          overflow: 'auto',
          maxWidth: 'none',
        },
      }}
      className="food-card-text"
    >
      {mostSellingFood}
    </CustomTypography>
              <Typography
                className="food-card-text"
                sx={{ color: isDarkMode ? "#fff" : "#30ba30" }}
              ></Typography>
            </div>
          </Paper>
        </Grid>
        {/* <Grid item xs={12} md={4}>
          <Paper
            sx={{
               p: {sm: 2 , xs: 1},
              display: "flex",
              justifyContent: "space-between",
              alignItems:"center",
              bgcolor: isDarkMode ? "#7A7A7A" : "#FFB3B2",
            }}
            elevation={3}
          >
            <div>
              <CustomTypography
                className="food-card-text"
                sx={{ ...reportscardstyle, display: "flex", alignItems: "center" }}
              >
                <EqualizerIcon
                  style={{ fontSize: "2rem", marginRight: "0.5rem" }}
                />{" "}
                Profit
              </CustomTypography>
            </div>
            <div>
              <CustomTypography sx={{...reportscardstyle, }} className="food-card-text">
                ---
              </CustomTypography>
            </div>
          </Paper>
        </Grid> */}
      </Grid>
      

      <Grid container spacing={3} mt={1}>
        {/* Bar Chart */}
        {range !== 'Custom' && (
        <Grid item xs={12} md={7.5}>
          <Paper
            sx={{
              padding: 1,
              bgcolor: isDarkMode ? "#404040" : "white",
              position: "relative",
            }}
            elevation={3}
          >
            <div style={{ height: 330, position: "relative" }}>
              <ResponsiveContainer>
                <AreaChart
                  width={430}
                  className="food-card-text"
                  height={250}
                  data={fillMissingData(
                    range === "Custom" || range === "Monthly"
                      ? monthlyData
                      : range === "Weekly"
                      ? weeklyData
                      : range === "Daily"
                      ? dailyData
                      : yearlyData,
                    range
                  )}
                  margin={{ top: 40, left: 5}}
                >
                  <defs>
                    <linearGradient id="colorUv" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8884D8" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#8884D8" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorPv" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0088FE" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#0088FE" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorXv" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#24A497" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#24A497" stopOpacity={0} />
                    </linearGradient>
                    <filter
                      id="shadow"
                      x="-20%"
                      y="-20%"
                      width="140%"
                      height="140%"
                    >
                      <feDropShadow
                        dx="0"
                        dy="4"
                        stdDeviation="2"
                        floodColor="#000000"
                        floodOpacity="0.2"
                      />
                    </filter>
                  </defs>
                  <XAxis
                    dataKey={
                      range === "Monthly"
                        ? "month"
                        : range === "Weekly"
                        ? "day"
                        : range === "Daily"
                        ? "hour"
                        : "year"
                    }
                    tickFormatter={getXAxisTickFormatter(range)}
                    tick={{ fill: isDarkMode ? "#FFFFFF" : "#000000", fontSize: '14px'  }}
                  />
                  <YAxis tick={{ fill: isDarkMode ? "#FFFFFF" : "#000000" , fontSize: '14px'}} />
                  <CartesianGrid strokeDasharray="3 3" />
                  <Tooltip />
                  <Area
                    type="monotone"
                    dataKey="cash"
                    stroke="#8884d8"
                    fillOpacity={1}
                    fill="url(#colorUv)"
                    filter="url(#shadow)" // Apply shadow filter
                  />
                  <Area
                    type="monotone"
                    dataKey="upi"
                    stroke="#0088FE"
                    fillOpacity={1}
                    fill="url(#colorPv)"
                    filter="url(#shadow)" // Apply shadow filter
                  />
                  <Area
                    type="monotone"
                    dataKey="card"
                    stroke="#24a497"
                    fillOpacity={1}
                    fill="url(#colorXv)"
                    filter="url(#shadow)" 
                  />
                  <text
                    x="100%" 
                    y="5%" 
                    textAnchor="end"
                    fill={isDarkMode ? "#FFFFFF" : "#000000"}
                    fontSize={12}
                    fontWeight="bold"
                    style={{
                      paddingRight: "10px",
                      paddingTop: "10px",
                      position: "absolute",
                    }} 
                  >
                    <tspan x="100%" dy="0em">
                      X-Axis:{" "}
                      {range === "Monthly"
                        ? "Months"
                        : range === "Weekly"
                        ? "Days"
                        : range === "Daily"
                        ? "Hours"
                        : "Years"}
                    </tspan>
                    <tspan x="100%" dy="1.2em">
                      Y-Axis: Amount
                    </tspan>{" "}
                  
                  </text>
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Paper>
        </Grid>
        )}
        {/* Pie Chart */}
        <Grid item xs={12} md={4.5}>
          <Paper
            sx={{
              p: 2,
              bgcolor: isDarkMode ? "#404040" : "white",
            }}
            elevation={3}
          >
            <ResponsiveContainer width="100%" height={265}>
              <PieChart
                className="food-card-text"
                sx={{ marginLeft: "20%" }}
                // Adjust the height as needed
                series={[
                  {
                    data: [
                      {
                        name: "Cash",
                        value:
                          range === "Custom"
                            ? customData.cash
                            : range === "Daily"
                            ? totalDailySales.cash
                            : range === "Weekly"
                            ? totalWeeklySales.cash
                            : range === "Monthly"
                            ? totalMonthlySales.cash
                            : totalYearlySales.cash,
                        color: "#0088FE", // Change the color for Cash
                      },
                      {
                        name: "Card",
                        value:
                          range === "Custom"
                            ? customData.card
                            : range === "Daily"
                            ? totalDailySales.card
                            : range === "Weekly"
                            ? totalWeeklySales.card
                            : range === "Monthly"
                            ? totalMonthlySales.card
                            : totalYearlySales.card,
                        color: "#00C49F",
                      },
                      {
                        name: "UPI",
                        value:
                          range === "Custom"
                            ? customData.upi
                            : range === "Daily"
                            ? totalDailySales.upi
                            : range === "Weekly"
                            ? totalWeeklySales.upi
                            : range === "Monthly"
                            ? totalMonthlySales.upi
                            : totalYearlySales.upi,
                        color: "#FFBB28",
                      },
                    ],
                    highlightScope: { faded: "global", highlighted: "item" },
                    faded: {
                      innerRadius: 30,
                      additionalRadius: -30,
                      color: "gray",
                    },
                  },
                ]}
              />
            </ResponsiveContainer>
            <Box sx={{ display: "flex", justifyContent: "center", flexWrap: "wrap" }} mt={3}>
  <Box sx={{ display: "flex", alignItems: "center", mr: 2 }}>
    <Box sx={{ height: "20px", width: "20px", backgroundColor: "#0088FE", mr: 1 }}></Box>
    <CustomTypography className="food-card-text" sx={{ ...reportscardstyle }} mr={2}>
      Cash :
      {range === "Custom"
        ? customData.cash
        : range === "Daily"
        ? totalDailySales.cash
        : range === "Weekly"
        ? totalWeeklySales.cash
        : range === "Monthly"
        ? totalMonthlySales.cash
        : totalYearlySales.cash}
    </CustomTypography>
  </Box>
  <Box sx={{ display: "flex", alignItems: "center", mr: 2 }}>
    <Box sx={{ height: "20px", width: "20px", backgroundColor: "#00C49F", mr: 1 }}></Box>
    <CustomTypography className="food-card-text"  sx={{ ...reportscardstyle }} mr={2}>
      Card :
      {range === "Custom"
        ? customData.card
        : range === "Daily"
        ? totalDailySales.card
        : range === "Weekly"
        ? totalWeeklySales.card
        : range === "Monthly"
        ? totalMonthlySales.card
        : totalYearlySales.card}
    </CustomTypography>
  </Box>
  <Box sx={{ display: "flex", alignItems: "center", mr: 2 }}>
    <Box sx={{ height: "20px", width: "20px", backgroundColor: "#FFBB28", mr: 1 }}></Box>
    <CustomTypography  sx={{ ...reportscardstyle }} className="food-card-text">
      Upi :
      {range === "Custom"
        ? customData.upi
        : range === "Daily"
        ? totalDailySales.upi
        : range === "Weekly"
        ? totalWeeklySales.upi
        : range === "Monthly"
        ? totalMonthlySales.upi
        : totalYearlySales.upi}
    </CustomTypography>
  </Box>
</Box>

          </Paper>
        </Grid>
      </Grid>
      <Grid container spacing={3} mt={1} mb={5}>
        <Grid
          item
          xs={12}
          md={8}
          style={{ display: "flex", flexDirection: "column" }}
        >
          <TableContainer
            sx={{ maxHeight: "45vh", overflow: "auto", height: "70vh" }}
          >
            <Table aria-label="simple table">
              <TableHead sx={tableHeadStyles}>
                <TableRow>
                  {tableHeaders.map((header, index) => (
                    <TableCell
                      key={index}
                      className="all-list-tabelcell"
                      align="right"
                      sx={tableCellStyles}
                    >
                      {header.label}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <div style={{ padding: "10px" }} />
              <TableBody>
                {productListData.length === 0 ? (
                  <TableRow sx={contentTableRowStyles}>
                    <TableCell colSpan={10} align="center">
                      <Typography
                        className="food-card-text"
                        sx={{
                          fontSize: {
                            xs: "11px",
                            sm: "14px",
                            md: "14px",
                            lg: "14px",
                            xl: "15px",
                          },
                        }}
                      >
                        :warning: Oops!, There are no records of category to
                        display.
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  productListData
                    .slice(startIndex, endIndex)
                    .map((row, index) => (
                      <TableRow key={index} sx={contentTableRowStyles}>
                        {renderStyledCell(
                          startIndex + index + 1,
                          getFontWeight(row.foodName)
                        )}
                        {renderStyledCell(
                          row.foodName,
                          getFontWeight(row.foodName)
                        )}
                        {renderStyledCell(
                          row.orderCount,
                          getFontWeight(row.orderCount)
                        )}
                        {renderStyledCell(
                          row.totalPrice,
                          getFontWeight(row.totalPrice)
                        )}
                      </TableRow>
                    ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <div style={{ marginTop: "15px", alignSelf: "flex-end" }}>
            <Pagination
              count={Math.ceil(productListData.length / itemsPerPage)}
              page={page}
              onChange={handleChangePage}
              variant="outlined"
              shape="rounded"
              size="large"
            />
          </div>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper
            sx={{ p: 2, bgcolor: isDarkMode ? "#404040" : "white" }}
            elevation={3}
          >
            <Box display="flex" bgcolor="primary.light" sx={listMainBox}>
              <StarIcon sx={listIconStyles} />
              <Typography variant="span" sx={{ ml: "8px" }}>
                Top Five Products
              </Typography>
            </Box>
            {productListData.slice(0, 5).map((item, index) => (
              <Box key={index} sx={{ mt: 2 }}>
                <CustomTypography
                  variant="body2"
                  className="food-card-text"
                  p={1}
                >
                  {item.foodName}
                </CustomTypography>
                <LinearProgress
                  variant="determinate"
                  title={`Order Count: ${item.orderCount}`}
                  value={item.orderCount}
                  color="success"
                />
              </Box>
            ))}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default SalesReport;
