import React, { useEffect, useState } from "react";
import {
  Box,
  Tabs,
  Button,
  CircularProgress,
  Grid,
  LinearProgress,
  Paper,
  Tab,
  Input,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  Pagination,
} from "@mui/material";
import {
  BarChart,
  value,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from "recharts";
import InventoryIcon from "@mui/icons-material/Inventory";
import { PieChart } from "@mui/x-charts/PieChart";
import { useDrawer } from "../Sidebar/DrawerContext";
import { useTableContext } from "../../Screens/tableContext/TableContext";
import StarIcon from "@mui/icons-material/Star";
import PointOfSaleIcon from "@mui/icons-material/PointOfSale";
import CreditCardIcon from "@mui/icons-material/CreditCard";
import { useDarkMode } from "../../Screens/DarkMode/DarkMode";
import AdUnitsIcon from "@mui/icons-material/AdUnits";
import PaymentIcon from "@mui/icons-material/Payment";
import CurrencyRupeeIcon from "@mui/icons-material/CurrencyRupee";
import { useSelector } from "react-redux";
import TrendingDownIcon from "@mui/icons-material/TrendingDown";
const itemsPerPage = 5;

const SalesReport = () => {
  const [productListData, SetProductListData] = useState([]);
  const [venodorListData, SetVendorListData] = useState([]);
  const [totalSales, setTotalSales] = useState(0); // Declare totalSales in state
  const [monthlySales, setMonthlySales] = useState([]);
  const [totalAllSales, setAllTotalSales] = useState({})

  const currentUser = useSelector((state) => state.auth.user.data);
  const { isDarkMode, CustomTypography } = useDarkMode();
  const [loading, setLoading] = useState(false);
  const {
    pdfAndExcelButtonStyles,
    listMainGridStyles,
    tableCellStyles,
    contentTableRowStyles,
    tableHeadStyles,
    listMainBox,
    listIconStyles,
    spaceBetweenTopComponent,
    listTabStyles,
    listTabsStyles,
    fromAndToTextStyles,
    dateFieldStyles,
     dailyStyle
  } = useDrawer();
  const { renderStyledCell, getFontWeight, resetCurrentPage } = useTableContext();
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [value, setValue] = useState(0);



  const tableHeaders = [
    { label: "SR No." },
    { label: "Product Name" },
    { label: "Quantity" },
    { label: "Total Cost" },

  ];

  const formatDate = (date) => {
    const year = date.getFullYear();
    let month = date.getMonth() + 1;
    let day = date.getDate();

    month = month < 10 ? '0' + month : month;
    day = day < 10 ? '0' + day : day;

    return `${year}-${month}-${day}`;
  };

  const getDayOfWeek = (date) => {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    return days[date.getDay()];
  };

  const [range, setRange] = useState('Monthly'); // Default to Monthly

  const handleButtonClick = (selectedRange) => {
    setRange(selectedRange);
  };

  const getXAxisTickFormatter = (range) => {
    switch (range) {
      case 'Daily':
        return (day) => day;
      case 'Weekly':
        return (day) => day;
      case 'Monthly':
        return (month) => month;
      case 'Yearly':
        return (year) => year;
      default:
        return null;
    }
  };

  const [weeklyData, setWeeklyData] = useState([]);
  const [totalWeeklySales, setTotalWeeklySales] = useState({ cash: 0, card: 0, upi: 0 });
  const [totalDailySales, setTotalDailySales] = useState({ cash: 0, card: 0, upi: 0 });
  const fetchWeeklyData = async () => {
    const today = new Date();
    const currentDay = today.getDay(); // Get the current day of the week (0 = Sunday, 1 = Monday, ..., 6 = Saturday)
    const currentDayName = getDayOfWeek(today); // Get the name of the current day (e.g., "Sun", "Mon", ..., "Sat")

    // Calculate the date range for the current week
    const daysToAdd = currentDay === 0 ? 0 : 7 - currentDay;
    const sunday = new Date(today);
    sunday.setDate(today.getDate() - currentDay);
    const saturday = new Date(today);
    saturday.setDate(today.getDate() + daysToAdd);

    const fromDate = formatDate(sunday);
    const toDate = formatDate(saturday);

    try {
      const response = await fetch(`https://apis.ubsbill.com/apptest/v2/balance/store/${currentUser.storeid}?page=0&size=50000&startDate=${fromDate}&endDate=${toDate}` , {
        headers: {
            'Authorization': `Bearer ${currentUser.token}`, 
            'Content-Type': 'application/json'
        }
    });
      const responseData = await response.json();
      const weeklySales = responseData.data.balance.map(item => ({
        day: getDayOfWeek(new Date(item.date)),
        cash: item.sales.cash,
        upi: item.sales.upi,
        card: item.sales.card
      }));
      //console.log('weeklySales', weeklySales);
      setWeeklyData(weeklySales);

      // Calculate total weekly sales
      let totalCash = weeklySales.reduce((total, item) => total + item.cash, 0);
      let totalCard = weeklySales.reduce((total, item) => total + item.card, 0);
      let totalUpi = weeklySales.reduce((total, item) => total + item.upi, 0);

      // Set total weekly sales in state
      setTotalWeeklySales({ cash: totalCash, card: totalCard, upi: totalUpi });
      //console.log('totalWeeklySales', totalWeeklySales);

      // Filter data for the current day and set it to totalDailySales
      const todayData = weeklySales.find(item => item.day === currentDayName);

      setTotalDailySales(todayData);
      //console.log('totalDailySales', totalDailySales);
      //console.log('currentDayName', currentDayName);

    } catch (error) {
      //console.error('Error fetching weekly data:', error);
    }
  };



  useEffect(() => {
    if (range === 'Weekly') {
      fetchWeeklyData();
    }
  }, [range]); // Fetch weekly data when range changes to 'Weekly'

  const [monthlyData, setMonthlyData] = useState([]);
  const [totalMonthlySales, setTotalMonthlySales] = useState({ cash: 0, card: 0, upi: 0 });
  const fetchMonthlyData = async () => {
    try {
      const response = await fetch(`https://apis.ubsbill.com/apptest/v2/report/totalWithMonth?storeId=${currentUser.storeid}&year=2024` , {
        headers: {
            'Authorization': `Bearer ${currentUser.token}`, 
            'Content-Type': 'application/json'
        }
    });
      const responseData = await response.json();

      console.log(responseData.data)

      const months = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
      const fetchedMonthlyData = months.map(month => ({
        month: getMonthName(month),
        cash: responseData.data[month]?.cash || 0,
        upi: responseData.data[month]?.upi || 0,
        card: responseData.data[month]?.card || 0
      }));
      //console.log('fetchedMonthlyData' , fetchedMonthlyData);
      setMonthlyData(fetchedMonthlyData);

      //for current month
      const currentMonth = new Date().getMonth() + 1; // Get the current month (1-12)
      const currentMonthData = fetchedMonthlyData.find(monthData => {
        return monthData.month === getMonthName(currentMonth);
      });

      //console.log('currentMonthData', currentMonthData)

      // Set the totalMonthlySales state with the data of the current month
      setTotalMonthlySales({
        cash: currentMonthData?.cash || 0,
        card: currentMonthData?.card || 0,
        upi: currentMonthData?.upi || 0
      });
      //console.log('totalfetchedMonthlyData' , totalMonthlySales);
      const totalSales = (currentMonthData?.cash || 0) + (currentMonthData?.card || 0) + (currentMonthData?.upi || 0);

      setTotalSales(totalSales);
      //console.log("mytital:" , totalSales)

    } catch (error) {
      //console.error("Error fetching monthly data:", error);
    }
  };

  const getMonthName = (monthNumber) => {
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    return monthNames[parseInt(monthNumber) - 1] || '';
  };

  useEffect(() => {
    fetchMonthlyData();
    filterDailyRecords();
  }, [totalSales]);



  const [yearlyData, setYearlyData] = useState([]);
  const [totalYearlySales, setTotalYearlySales] = useState({ cash: 0, card: 0, upi: 0 });

  const fetchYearlyData = async () => {
    try {
      const currentYear = new Date().getFullYear();
      const startYear = currentYear - 4;
      const response = await fetch(`https://apis.ubsbill.com/apptest/v2/report/totalWithYear?storeId=${currentUser.storeid}&startYear=${startYear}&endYear=${currentYear}` ,
      {
        headers: {
            'Authorization': `Bearer ${currentUser.token}`, 
            'Content-Type': 'application/json'
        }
    }
      );
      const responseData = await response.json();

      const fetchedYearlyData = responseData.data.map(item => ({
        year: item.year.toString(),
        cash: item.cash || 0,
        upi: item.upi || 0,
        card: item.card || 0
      }));

      setYearlyData(fetchedYearlyData);
      //console.log('fetchedYearlyData' , fetchedYearlyData)


      const currentYearData = fetchedYearlyData.find(yearData => yearData.year === currentYear.toString());

      setTotalYearlySales({
        cash: currentYearData?.cash || 0,
        card: currentYearData?.card || 0,
        upi: currentYearData?.upi || 0
      });
      //console.log('fsdgrggffdfgsdfsd' , totalYearlySales)
    } catch (error) {
      //console.error("Error fetching yearly data:", error);
    }
  };

  useEffect(() => {
    fetchYearlyData();
  }, []);

  const fillMissingData = (data, range) => {
    if (range === 'Monthly') {
      const filledData = [];
      const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      for (let i = 0; i < months.length; i++) {
        const monthData = data.find(item => item.month === months[i]);
        filledData.push(monthData || { month: months[i], cash: 0, upi: 0, card: 0 });
      }
      return filledData;
    } else if (range === 'Weekly' || range === 'Daily') {
      const filledData = [];
      const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
      for (let i = 0; i < days.length; i++) {
        const dayData = data.find(item => item.day === days[i]);
        filledData.push(dayData || { day: days[i], cash: 0, upi: 0, card: 0 });
      }
      return filledData;
    } else if (range === 'Yearly') {
      const filledData = [];
      const years = ["2021","2022", "2023", "2024"]; // Example years
      for (let i = 0; i < years.length; i++) {
        const yearData = data.find(item => item.year === years[i]);
        filledData.push(yearData || { year: years[i], cash: 0, upi: 0, card: 0 });
      }
      return filledData;
    }
    return [];
  };


  const expiredProductsCount = productListData.filter(
    (item) => new Date(item.expiryDate) < new Date()
  ).length;

  const groupInventoryDataByMonth = (inventoryList) => {
    const groupedData = inventoryList.reduce((acc, item) => {
      const month = new Date(item.inventoryDate).toLocaleString("default", {
        month: "long",
      });
      if (!acc[month]) {
        acc[month] = { month, MonthlyWiseReport: 0 };
      }
      acc[month].MonthlyWiseReport += item.quantity; // Assuming quantity is the property representing inventory
      return acc;
    }, {});

    return Object.values(groupedData);
  };

  // Function to aggregate data by item name for the current month
  const aggregateDataForCurrentMonth = (inventoryList) => {
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth() + 1; // January is 0, so add 1 to get the current month
    const aggregatedData = {};

    inventoryList.forEach((item) => {
      const itemDate = new Date(item.inventoryDate);
      const itemMonth = itemDate.getMonth() + 1; // January is 0, so add 1 to get the month

      if (itemMonth === currentMonth) {
        if (aggregatedData[item.name]) {
          aggregatedData[item.name] += item.quantity;
        } else {
          aggregatedData[item.name] = item.quantity;
        }
      }
    });

    return aggregatedData;
  };
  // Function to convert aggregated data to format suitable for pie chart
  const preparePieChartData = (aggregatedData) => {
    // Convert object to array of objects
    const dataArray = Object.keys(aggregatedData).map((itemName) => ({
      name: itemName,
      value: aggregatedData[itemName],
    }));

    // Sort the array based on the quantity in descending order
    const sortedArray = dataArray.sort((a, b) => b.value - a.value);

    // Take only the top 5 items
    const topFive = sortedArray.slice(0, 5);

    return topFive;
  };
  // Inside your component
  const aggregatedData = aggregateDataForCurrentMonth(productListData);
  const pieChartData = preparePieChartData(aggregatedData);

  // Sort the array based on quantity in descending order
  const sortedInventory = productListData.sort(
    (a, b) => b.quantity - a.quantity
  );

  // Take only the top five items
  const topFiveItems = sortedInventory.slice(0, 10);



  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"];

  const RADIAN = Math.PI / 180;
  const renderCustomizedLabel = ({
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    percent,
    index,
  }) => {
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text
        x={x}
        y={y}
        fill="white"
        textAnchor={x > cx ? "start" : "end"}
        dominantBaseline="central"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };
  const setMonthlyAndTotalSales = (monthlySalesData) => {

    const { totalSales } = monthlySalesData;

    setTotalSales(totalSales);
  };

  const generateEmptyMonthlyData = () => {
    const emptyData = [];
    for (let i = 0; i < 12; i++) {
      emptyData.push({
        month: i + 1, // Month index starts from 1
        year: new Date().getFullYear(), // Default to current year
        cash: 0,
        card: 0,
        upi: 0,
      });
    }
    return emptyData;
  };


  const fetchProductData = async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `https://apis.ubsbill.com/apptest/v2/report/mostSellingFoodByDate/${currentUser.storeid}?startDate=${fromDate}&endDate=${toDate}` ,
        {
          headers: {
              'Authorization': `Bearer ${currentUser.token}`, 
              'Content-Type': 'application/json'
          }
      }
      );
      const responseData = await response.json();
      SetProductListData(responseData.data)
    } catch (error) {
      //console.error("Error fetching inventory data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProductData();
  }, [fromDate, toDate , value]);


  const handleChange = (event, newValue) => {
    setValue(newValue);
    switch (newValue) {
      case 0:
        filterDailyRecords();
        break;
      case 1:
        filterMonthlyRecords();
        break;
      case 2:
        filterYearlyRecords();
        break;
      default:
        break;
    }
  };


  const filterDailyRecords = () => {
    const today = new Date();
    const fromDateFormatted = formatDate(today);
    const toDateFormatted = formatDate(today);
    setFromDate(fromDateFormatted);
    setToDate(toDateFormatted);
    resetCurrentPage();
  };

  const filterMonthlyRecords = () => {
    const today = new Date();
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const lastDayOfMonth = new Date(
      today.getFullYear(),
      today.getMonth() + 1,
      0
    );
    const fromDateFormatted = formatDate(firstDayOfMonth);
    const toDateFormatted = formatDate(lastDayOfMonth);
    setFromDate(fromDateFormatted);
    setToDate(toDateFormatted);
    resetCurrentPage();
  };


  const filterYearlyRecords = () => {
    const today = new Date();
    const firstDayOfYear = new Date(today.getFullYear(), 0, 1);
    const lastDayOfYear = new Date(today.getFullYear(), 11, 31);
    const fromDateFormatted = formatDate(firstDayOfYear);
    const toDateFormatted = formatDate(lastDayOfYear);
    setFromDate(fromDateFormatted);
    setToDate(toDateFormatted);
    resetCurrentPage();
  };

  // Pagination 

  const [page, setPage] = useState(1);

  const handleChangePage = (event, newPage) => { setPage(newPage); };

  const startIndex = (page - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;

  return (
    <Box component="main">
      <Grid item xs={12} sx={listMainGridStyles}>
        <Box display="flex" bgcolor="primary.light" sx={listMainBox}>
          <InventoryIcon sx={listIconStyles} />
          <Typography variant="span" sx={{ ml: "8px" }}>
            Reports
          </Typography>
        </Box>
        <Box sx={spaceBetweenTopComponent}>
          <Button
            className="food-card-text mode-button border-radius-10 cart-button final-button"
            sx={pdfAndExcelButtonStyles}
          >
            PDF
          </Button>
          <Button
            className="food-card-text mode-button border-radius-10 cart-button final-button"
            sx={pdfAndExcelButtonStyles}
          >
            Excel
          </Button>
        </Box>
      </Grid>

      <Grid container spacing={3} mt={2} justifyContent="space-evenly">
        {/* Bar Chart */}
        <Grid item xs={6} sm={4.2} md={4} lg={2.7} xl={3}>
          <Paper
            sx={{
              p: 1,
              display: "flex",
              justifyContent: "space-between",
              bgcolor: isDarkMode ? "#7A7A7A" : "#EAFCFC",
            }}
            elevation={3}
          >
            <div>
              <CustomTypography
                className="food-card-text"
                sx={{ display: "flex", alignItems: "center" }}
              >
                <TrendingDownIcon
                  style={{ fontSize: "2rem", marginRight: "0.5rem" }}
                />{" "}
                Total Sales
              </CustomTypography>
            </div>
            <div>
              <CustomTypography className="food-card-text">
                {loading ? (
                  <CircularProgress sx={{ color: "#24A497" }} />
                ) : (
                  totalSales
                )}
              </CustomTypography>{" "}
            </div>
          </Paper>
        </Grid>

        <Grid item xs={6} sm={4.2} md={4} lg={2.7} xl={3}>
          <Box
            bgcolor="#D9D9D9"
            sx={dailyStyle}
          >
            <Tabs
              value={value}
              onChange={handleChange}
              textColor="white"
              indicatorColor="white"
              aria-label="tabs"
              sx={listTabsStyles}
            >
              <Tab
                label="Daily"
                value={0}
                className="tabs"
                onClick={() => handleButtonClick('Daily')}
                sx={{
                  ...listTabStyles,
                  bgcolor: value === 0 ? (isDarkMode ? "#fff" : "#28A497") : (isDarkMode ? "#7a7a7a" : "inherit"),
                  color: value === 0 ? (isDarkMode ? "black" : "white") : (isDarkMode ? "white" : "black"),
                }}
              />
              <Tab
                label="Monthly"
                value={1}
                onClick={() => handleButtonClick('Monthly')}
                sx={{
                  ...listTabStyles,
                  bgcolor: value === 1 ? (isDarkMode ? "#fff" : "#28A497") : (isDarkMode ? "#7a7a7a" : "inherit"),
                  color: value === 1 ? (isDarkMode ? "black" : "white") : (isDarkMode ? "white" : "black"),
                }}
              />
              <Tab
                label="Yearly"
                value={2}
                onClick={() => handleButtonClick('Yearly')}
                sx={{
                  ...listTabStyles,
                  bgcolor: value === 2 ? (isDarkMode ? "#fff" : "#28A497") : (isDarkMode ? "#7a7a7a" : "inherit"),
                  color: value === 2 ? (isDarkMode ? "black" : "white") : (isDarkMode ? "white" : "black"),
                }}
              />
            </Tabs>
          </Box>
        </Grid>

        <Grid item xs={7} sm={4} md={4} lg={2.6} xl={2.3}>
          <Box bgcolor="#D9D9D9" p={1} sx={fromAndToTextStyles}>
            From
            <Input
              fullWidth
              type="date"
              id="outlined-basic"
              label="Outlined"
              variant="outlined"
              sx={dateFieldStyles}
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              disableUnderline
            />
          </Box>
        </Grid>
        <Grid item xs={7} sm={4} md={4} lg={2.6} xl={2.3}>
          <Box bgcolor="#D9D9D9" p={1} sx={fromAndToTextStyles}>
            To
            <Input
              fullWidth
              type="date"
              id="outlined-basic"
              label="Outlined"
              variant="outlined"
              value={toDate}
              sx={dateFieldStyles}
              onChange={(e) => setToDate(e.target.value)}
              disableUnderline
            />
          </Box>
        </Grid>
      </Grid>

      <Grid container spacing={3} mt={1}>
        {/* Bar Chart */}
        <Grid item xs={12} md={8}>
          {/* <Button variant="outlined" onClick={() => handleButtonClick('Daily')}>Daily</Button>
          <Button variant="outlined" onClick={() => handleButtonClick('Weekly')}>Weekly</Button>
          <Button variant="outlined" onClick={() => handleButtonClick('Monthly')}>Monthly</Button>
          <Button variant="outlined" onClick={() => handleButtonClick('Yearly')}>Yearly</Button> */}
          <Paper
            sx={{ p: 2, bgcolor: isDarkMode ? "#404040" : "white" }}
            elevation={3}
          >
            <div style={{ height: 300 }}>
              <ResponsiveContainer>
                <AreaChart
                  width={730}
                  height={250}
                  data={fillMissingData(range === 'Monthly' ? monthlyData : (range === 'Weekly' || range === 'Daily' ? weeklyData : yearlyData), range)}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="colorUv" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8884D8" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#8884D8" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorPv" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#82CA9D" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#82CA9D" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorXv" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#24A497" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#24A497" stopOpacity={0} />
                    </linearGradient>
                    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
                      <feDropShadow dx="0" dy="4" stdDeviation="2" floodColor="#000000" floodOpacity="0.2" />
                    </filter>
                  </defs>
                  <XAxis
                    dataKey={range === 'Monthly' ? 'month' : (range === 'Weekly' || range === 'Daily' ? 'day' : 'year')}
                    tickFormatter={getXAxisTickFormatter(range)}
                  />
                  <YAxis />
                  <CartesianGrid strokeDasharray="3 3" />
                  <Tooltip />
                  <Area
                    type="monotone"
                    dataKey="cash"
                    stroke="#8884d8"
                    fillOpacity={1}
                    fill="url(#colorUv)"
                    filter="url(#shadow)" // Apply shadow filter
                  />
                  <Area
                    type="monotone"
                    dataKey="upi"
                    stroke="#82ca9d"
                    fillOpacity={1}
                    fill="url(#colorPv)"
                    filter="url(#shadow)" // Apply shadow filter
                  />
                  <Area
                    type="monotone"
                    dataKey="card"
                    stroke="#24a497"
                    fillOpacity={1}
                    fill="url(#colorXv)"
                    filter="url(#shadow)" // Apply shadow filter
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

          </Paper>
        </Grid>
        {/* Pie Chart */}
        <Grid item xs={12} md={4}>
          <Paper
            sx={{ p: 2, bgcolor: isDarkMode ? "#404040" : "white" }}
            elevation={3}
          >
            <div style={{ height: 300 }}>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart
                  className="food-card-text"
                  width={200} // Adjust the width as needed
                  height={300} // Adjust the height as needed
                  series={[
                    {
                      data: [
                        {
                          name: "Cash",
                          value: range === "Daily" ? totalDailySales.cash : range === "Weekly" ? totalWeeklySales.cash : range === "Monthly" ? totalMonthlySales.cash : totalYearlySales.cash,
                          label: `Cash : ${range === "Daily" ? totalDailySales.cash : range === "Weekly" ? totalWeeklySales.cash : range === "Monthly" ? totalMonthlySales.cash : totalYearlySales.cash}`,
                          color: "#24A497", // Change the color for Cash
                        },
                        {
                          name: "Card",
                          value: range === "Daily" ? totalDailySales.card : range === "Weekly" ? totalWeeklySales.card : range === "Monthly" ? totalMonthlySales.card : totalYearlySales.card,
                          label: `Card : ${range === "Daily" ? totalDailySales.card : range === "Weekly" ? totalWeeklySales.card : range === "Monthly" ? totalMonthlySales.card : totalYearlySales.card}`,
                          color: "#FFC658",
                        },
                        {
                          name: "UPI",
                          value: range === "Daily" ? totalDailySales.upi : range === "Weekly" ? totalWeeklySales.upi : range === "Monthly" ? totalMonthlySales.upi : totalYearlySales.upi,
                          label: `Upi : ${range === "Daily" ? totalDailySales.upi : range === "Weekly" ? totalWeeklySales.upi : range === "Monthly" ? totalMonthlySales.upi : totalYearlySales.upi}`,
                          color: "#154755",
                        },
                      ],
                      highlightScope: { faded: "global", highlighted: "item" },
                      faded: {
                        innerRadius: 30,
                        additionalRadius: -30,
                        color: "gray",
                      },
                    },
                  ]}
                />
              </ResponsiveContainer>
            </div>
          </Paper>
        </Grid>
      </Grid>

      <Grid container spacing={3} mt={1} mb={5}>
        <Grid item xs={12} md={8} style={{ display: 'flex', flexDirection: 'column' }}>
          <TableContainer sx={{ maxHeight: "45vh", overflow: "auto", height: "70vh" }}>
            <Table aria-label="simple table">
              <TableHead sx={tableHeadStyles}>
                <TableRow>
                  {tableHeaders.map((header, index) => (
                    <TableCell key={index} className="all-list-tabelcell" align="right" sx={tableCellStyles}>
                      {header.label}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <div style={{ padding: "10px" }} />
              <TableBody>
                {productListData.length === 0 ? (
                  <TableRow sx={contentTableRowStyles}>
                    <TableCell colSpan={10} align="center">
                      <Typography className="food-card-text" sx={{ fontSize: { xs: "11px", sm: "14px", md: "14px", lg: "14px", xl: "15px", } }}>
                        :warning: Oops!, There are no records of category to display.
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  productListData.slice(startIndex, endIndex).map((row, index) => (
                    <TableRow key={index} sx={contentTableRowStyles}>
                      {renderStyledCell(startIndex + index + 1, getFontWeight(row.foodName))}
                      {renderStyledCell(row.foodName, getFontWeight(row.foodName))}
                      {renderStyledCell(row.orderCount, getFontWeight(row.orderCount))}
                      {renderStyledCell(row.totalPrice, getFontWeight(row.totalPrice))}
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <div style={{ marginTop: '15px', alignSelf: 'flex-end' }}>
            <Pagination
              count={Math.ceil(productListData.length / itemsPerPage)}
              page={page}
              onChange={handleChangePage}
              variant="outlined"
              shape="rounded"
              size="large"
            />
          </div>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper
            sx={{ p: 2, bgcolor: isDarkMode ? "#404040" : "white" }}
            elevation={3}
          >
            <Box display="flex" bgcolor="primary.light" sx={listMainBox}>
              <StarIcon sx={listIconStyles} />
              <Typography variant="span" sx={{ ml: "8px" }}>
                Top Five Products
              </Typography>
            </Box>
            {productListData.slice(0, 5).map((item, index) => (
              <Box key={index} sx={{ mt: 2 }}>
                <CustomTypography
                  variant="body2"
                  className="food-card-text"
                  p={1}
                >
                  {item.foodName}
                </CustomTypography>
                <LinearProgress
                  variant="determinate"
                  title={`Order Count: ${item.orderCount}`}
                  value={item.orderCount}
                  color="success"
                />
              </Box>
            ))}
          </Paper>
        </Grid>

      </Grid>
    </Box>
  );
};

export default SalesReport;