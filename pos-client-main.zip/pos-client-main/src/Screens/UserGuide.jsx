import {  } from '@mui/material'
import { Box } from '@mui/system'
import React from 'react'
import { useDarkMode } from './DarkMode/DarkMode';

function UserGuide() {
  const { isDarkMode, toggleDarkMode , CustomTypography} = useDarkMode();
  return (
    <Box>
        <CustomTypography>User Guide</CustomTypography>
    </Box>
  )
}

export default UserGuide
