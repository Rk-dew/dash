import React from 'react'

function StoreSettingsSuperadmin() {
  return (
    <div>
      Store Settings
    </div>
  )
}

export default StoreSettingsSuperadmin
